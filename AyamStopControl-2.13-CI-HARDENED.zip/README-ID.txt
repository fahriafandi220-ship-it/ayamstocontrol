AYAM STOP CONTROL — VERSI 2.13

Pembaruan 2.7 — kalibrasi berdasarkan rekaman gameplay asli:
- Rekaman 720x1600 berdurasi sekitar 61,6 detik berhasil dianalisis.
- Area permainan yang terlihat pada rekaman berada kira-kira pada y=312 sampai y=957 px, dengan lebar layar penuh. Crop default 0.195–0.598 kini didokumentasikan berdasarkan pengamatan rekaman tersebut.
- Rekaman memperlihatkan halaman game di Chrome dan pilihan tingkat Easy. Karena hanya satu sesi/mode yang terlihat jelas, jumlah lajur untuk mode Normal 24 dan Nekat Parah 15 belum dianggap tervalidasi.
- Garis lintasan ayam belum dipastikan secara visual; posisi 78% tetap nilai sementara dan tidak boleh dipakai sebagai keputusan aman.
- Menambahkan catatan kalibrasi dan batas bukti pada GAMEPLAY-VIDEO-OBSERVATIONS-ID.txt.

Kemampuan yang memang ada:
- Meminta izin Android MediaProjection untuk membaca layar.
- Mengambil sampel gambar dan menganalisis perubahan visual.
- Melacak blob/jejak gerak dan pola arah visual secara kasar.
- Mengelompokkan koordinat menjadi bin sementara 24 dan 15 posisi.
- Memperkirakan waktu ke garis bawah/garis sementara berdasarkan sampling sekitar 5 Hz.

Batasan penting:
- Belum mengenali objek sebagai mobil atau motor secara andal.
- Belum mengukur kecepatan kendaraan dalam km/jam.
- Bin 24/15 belum mengikuti garis lajur game yang terdeteksi; itu hanya pembagian koordinat.
- Garis crossing 78% belum dikalibrasi ke posisi ayam.
- Belum menghasilkan keputusan jalur AMAN/BAHAYA yang tervalidasi.
- Tombol STOP/LANJUT belum mengendalikan karakter di game.
- Rekaman yang dianalisis hanya menunjukkan sesi/mode yang terlihat pada video; belum membuktikan semua mode atau kondisi permainan.
- APK Android belum dibangun dan diuji di perangkat pada sesi ini. Gunakan GitHub Actions untuk menjalankan tes dan build APK.

Jangan menganggap estimasi visual sebagai jaminan keselamatan atau rekomendasi taruhan.


## Versi 2.8 — interval analisis terukur

Prediksi waktu menuju garis ayam kini memakai selang waktu aktual antar-frame dari timestamp MediaProjection/ImageReader, lalu dihaluskan agar tidak terlalu berubah akibat frame terlambat atau terlewat. Jika timestamp tidak tersedia, sistem memakai nilai awal 0,2 detik per sampel, lalu timestamp aktual mengoreksinya. Rentang tetap indikatif (ketidakpastian ±35%), bukan jaminan waktu tabrakan atau keputusan aman. Pengujian mencakup interval 0,8 detik dan penolakan interval tidak valid.


## Versi 2.9 — deteksi kandidat garis pemisah lajur

Penganalisis kini memindai kontras vertikal pada resolusi penuh di area permainan yang sudah dikalibrasi, lalu melaporkan kandidat garis pemisah berulang beserta tingkat keyakinannya. Cara ini tidak bergantung pada gambar 64 piksel yang dapat menghilangkan garis putus-putus tipis. Hasilnya hanya koordinat garis pemisah; sistem belum menyimpulkan jumlah lajur, mengenali jenis kendaraan, atau menyatakan lajur aman. Bin koordinat 24/15 tetap sementara sampai tiap mode game diamati dan dikalibrasi. Uji pada empat frame video yang jelas menemukan delapan kandidat garis dengan keyakinan 98% pada masing-masing frame; ini uji pemindaian gambar, bukan validasi semua kondisi permainan.


Versi 2.10: stabilisasi temporal deteksi batas jalur. Kandidat garis baru ditampilkan sebagai batas stabil setelah tiga frame berturut-turut cocok; perubahan tata letak mendadak atau deteksi yang hilang menghapus konfirmasi. Ini mengurangi kedipan peta jalur, tetapi belum mengidentifikasi kendaraan atau menyatakan jalur aman.


## Versi 2.12 — penyaringan prediksi lintasan yang lebih ketat

Pelacakan blob kini mencatat berapa kali arah gerak sebuah jejak berubah. Estimasi waktu menuju garis ayam hanya dibuat untuk jejak yang sudah terlihat minimal tiga kali, terdeteksi pada sampel terkini, bergerak turun, dan belum mengalami pembalikan arah. Tujuannya mengurangi prediksi dari kilatan/gerakan sesaat atau jejak yang arahnya tidak stabil. Konsekuensinya, prediksi dapat muncul lebih lambat; sistem tetap belum mengenali semantik mobil/motor dan tidak boleh dianggap sebagai penentu aman. Tes Kotlin mandiri memeriksa pembalikan arah, penolakan jejak pendek/tidak stabil, serta prediksi untuk jejak stabil.


## Versi 2.12 — penyaringan keyakinan pendekatan bawah

Ringkasan pendekatan bawah sekarang hanya menerima jejak yang teramati minimal tiga kali, masih terlihat pada frame terbaru, bergerak ke bawah, dan tidak memiliki catatan pembalikan arah. Ini mengurangi indikator urgensi yang berasal dari jejak lama atau bising. Fitur ini tetap penyaringan gerakan visual, bukan pengenalan mobil/motor atau keputusan keselamatan.


## Versi 2.13 — deskripsi bentuk gerakan sederhana

Ditambahkan pengelompokan proporsi siluet objek menjadi melebar, memanjang, kompak, atau ambigu. Ini hanya geometri, bukan pengenalan mobil atau motor dan tidak boleh dipakai untuk keputusan keselamatan. Bentuk ambigu tetap tidak diklasifikasikan. Tes unit mencakup semua kategori serta bentuk terlalu kecil/di tengah kategori.


## Integrasi gerbang keputusan live (18 November 2026)
FrameChangeAnalyzer meneruskan track turun yang memiliki prediksi ke CrossingDecisionEngine. Hasilnya ditampilkan pada notifikasi. Sampai posisi ayam, indeks lajur ayam, dan cakupan lajur per mode dikalibrasi, status live tetap DATA BELUM CUKUP. Status ini disengaja agar aplikasi tidak memberikan LANJUT yang belum didukung data.
