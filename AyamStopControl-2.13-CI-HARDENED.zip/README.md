# Ayam Stop Control — Version 2.13

Version 2.9 documents the first calibration pass against the actual supplied gameplay recording (720x1600 portrait, approximately 61.6 seconds). The visible game arena in that recording spans approximately y=312..957 px across the screen, matching the configurable default crop fractions 0.195..0.598.

The recording shows the game in Chrome with the Easy difficulty option visible/selected. It does **not** validate the requested 24-lane Normal or 15-lane Nekat Parah layouts, and it does not establish the chicken crossing row. The 78% crossing row remains provisional.

Implemented: Android screen capture, frame-based visual motion/blob tracking, coarse direction-pattern analysis, candidate-shape filtering, provisional 24/15 coordinate bins, and an indicative time-to-crossing range.

Not implemented/validated: reliable car-versus-motorcycle recognition, km/h speed measurement, actual lane-boundary detection, safe-lane decisions, automatic game input, or a working STOP/LANJUT action that controls the character. The coordinate bins are not game-lane detections.

The crossing row is provisional (78% of sampled playfield height), and the time range is a rough estimate based on approximately 2 samples/second with ±35% uncertainty. Do not use it as a safety guarantee or betting recommendation. Android APK build and device testing have not been completed here. Use the GitHub Actions workflow to run unit tests and build the debug APK.


## Versi 2.8 — interval analisis terukur

Prediksi waktu menuju garis ayam kini memakai selang waktu aktual antar-frame dari timestamp MediaProjection/ImageReader, lalu dihaluskan agar tidak terlalu berubah akibat frame terlambat atau terlewat. Jika timestamp tidak tersedia, sistem memakai nilai cadangan 0,5 detik per sampel. Rentang tetap indikatif (ketidakpastian ±35%), bukan jaminan waktu tabrakan atau keputusan aman. Pengujian mencakup interval 0,8 detik dan penolakan interval tidak valid.


## Version 2.9 — observed lane-divider scan

The analyzer now scans full-resolution vertical contrast inside the calibrated playfield crop and reports repeated lane-divider candidates with a confidence score. This avoids relying on 64-pixel-wide downsampled frames, which can erase thin dashed separators. The scan reports divider coordinates only; it does not infer a lane count, classify vehicles, or declare a lane safe. The 24/15 coordinate bins remain provisional until each game mode is observed and calibrated.


Versi 2.10: stabilisasi temporal deteksi batas jalur. Kandidat garis baru ditampilkan sebagai batas stabil setelah tiga frame berturut-turut cocok; perubahan tata letak mendadak atau deteksi yang hilang menghapus konfirmasi. Ini mengurangi kedipan peta jalur, tetapi belum mengidentifikasi kendaraan atau menyatakan jalur aman.


## Version 2.12 — stricter trajectory prediction gate

Blob tracks now record direction reversals. Time-to-crossing estimates require at least three observations, a current-frame detection, downward motion, and no direction reversal. This reduces transient/noisy trajectory predictions, at the cost of a later first estimate. It is still not semantic car/motorcycle recognition or a safety decision.


## Version 2.12 — stricter bottom-approach confidence gate

Bottom-approach bands now accept only tracks observed at least three times, present in the current frame, moving downward, and with no recorded direction reversal. This reduces stale/noisy urgency indicators. It remains visual-motion filtering, not car/motorcycle recognition or a safety verdict.


## Version 2.13 — coarse motion-shape descriptors

Added a conservative silhouette-proportion helper that labels foreground blobs as wide, tall, compact, or ambiguous. This is geometry only: it does not identify cars or motorcycles and cannot support a safety decision. Ambiguous shapes remain explicitly unclassified. Unit tests cover each class and tiny/intermediate silhouettes.
