package com.example.ayamstopcontrol

import android.media.Image
import kotlin.math.abs

/**
 * Lightweight frame-to-frame change estimator.
 * It measures changed screen regions only; it does NOT identify cars, motorcycles,
 * lanes, or the chicken and must not be used as a safety decision by itself.
 */
internal class FrameChangeAnalyzer(
    private val sampleWidth: Int = 64,
    private val sampleHeight: Int = 36,
    private val playfieldRegion: GamePlayfieldRegion = GamePlayfieldRegion(),
    crossingLineCalibration: CrossingLineCalibration = CrossingLineCalibration()
) {
    private var previous: IntArray? = null
    private var previousImageTimestampNs: Long? = null
    // Capture is throttled to ~5 Hz; measured Image timestamps replace this estimate.
    private var smoothedSampleIntervalSeconds = 0.2
    private val motionEstimator = BlockMotionEstimator(sampleWidth, sampleHeight)
    private val blobDetector = MotionBlobDetector(sampleWidth, sampleHeight)
    private val backgroundModel = AdaptiveBackgroundModel(sampleWidth * sampleHeight)
    private val blobTracker = MotionBlobTracker()
    private val candidateFilter = MotionObjectCandidateFilter()
    private val bottomApproachEstimator = BottomApproachEstimator(sampleHeight)
    // Provisional crossing row; calibrate against the chicken path in each game mode.
    private val crossingEstimator = TimeToCrossingEstimator(crossingY = crossingLineCalibration.rowFor(sampleHeight), frameHeight = sampleHeight)
    private val normalLaneEstimator = LaneActivityEstimator(sampleWidth, 24)
    private val hardLaneEstimator = LaneActivityEstimator(sampleWidth, 15)
    private val normalLaneStabilizer = LaneActivityStabilizer()
    private val hardLaneStabilizer = LaneActivityStabilizer()
    private val laneBoundaryDetector = LaneBoundaryDetector()
    private val laneBoundaryStabilizer = LaneBoundaryStabilizer()
    private val crossingDecisionEngine = CrossingDecisionEngine()

    data class Result(
        val changedPercent: Int,
        val activeRegions: Int,
        val totalRegions: Int,
        val movingBlocks: Int,
        val movingDownBlocks: Int,
        val movingUpBlocks: Int,
        val motionZoneCounts: IntArray,
        val motionBlobCount: Int,
        val largestBlobArea: Int,
        val foregroundPixelCount: Int,
        val objectCandidateCount: Int,
        val rejectedBlobCount: Int,
        val trackedMotionCount: Int,
        val trackedDownCount: Int,
        val trackedUpCount: Int,
        val horizontalMotionTrackCount: Int,
        val verticalDownCandidateCount: Int,
        val nearestDownFramesToBottom: Int?,
        val nearestDownSamplesToChickenRow: Int?,
        val nearestCrossingSecondsRange: ClosedFloatingPointRange<Double>?,
        val downTracksNearBottom: Int,
        val downwardBandCounts: IntArray,
        val downwardBandNearestSamples: IntArray,
        val downwardBandUrgency: List<BottomApproachEstimator.BandUrgency>,
        val normal24LaneSummary: LaneActivityEstimator.Summary,
        val hard15LaneSummary: LaneActivityEstimator.Summary,
        val stableNormal24LaneSummary: LaneActivityStabilizer.Summary,
        val stableHard15LaneSummary: LaneActivityStabilizer.Summary,
        val detectedLaneBoundariesX: List<Int>,
        val laneBoundaryConfidence: Double,
        val stableLaneBoundariesX: List<Int>,
        val stableLaneBoundaryConfidence: Double,
        val wideShapeCandidates: Int = 0,
        val tallShapeCandidates: Int = 0,
        val compactShapeCandidates: Int = 0,
        val ambiguousShapeCandidates: Int = 0,
        val recommendation: CrossingDecisionEngine.Recommendation = CrossingDecisionEngine.Recommendation.DATA_BELUM_CUKUP
    )

    fun analyze(image: Image): Result {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        val width = image.width
        val height = image.height
        val laneDetection = detectLaneBoundaries(image, playfieldRegion)
        val stableLaneDetection = laneBoundaryStabilizer.update(laneDetection)
        val current = IntArray(sampleWidth * sampleHeight)
        val bytes = buffer.duplicate()

        for (sy in 0 until sampleHeight) {
            val y = playfieldRegion.sampleY(sy, sampleHeight, height)
            for (sx in 0 until sampleWidth) {
                val x = playfieldRegion.sampleX(sx, sampleWidth, width)
                val offset = y * rowStride + x * pixelStride
                if (offset + 2 >= bytes.limit()) continue
                val r = bytes.get(offset).toInt() and 0xff
                val g = bytes.get(offset + 1).toInt() and 0xff
                val b = bytes.get(offset + 2).toInt() and 0xff
                current[sy * sampleWidth + sx] = (r * 30 + g * 59 + b * 11) / 100
            }
        }

        val old = previous
        previous = current
        val timestampNs = image.timestamp
        val priorTimestampNs = previousImageTimestampNs
        if (timestampNs > 0L && priorTimestampNs != null && timestampNs > priorTimestampNs) {
            val measuredSeconds = ((timestampNs - priorTimestampNs) / 1_000_000_000.0).coerceIn(0.2, 2.0)
            smoothedSampleIntervalSeconds = smoothedSampleIntervalSeconds * 0.7 + measuredSeconds * 0.3
        }
        if (timestampNs > 0L) previousImageTimestampNs = timestampNs
        val motion = motionEstimator.update(current)
        if (old == null) {
            val emptyApproaches = emptyList<BottomApproachEstimator.Approach>()
            val normal = normalLaneEstimator.summarize(emptyApproaches)
            val hard = hardLaneEstimator.summarize(emptyApproaches)
            backgroundModel.update(current)
            return Result(0, 0, 48, 0, 0, 0, IntArray(9), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, null, null, null, 0,
                IntArray(6), IntArray(6) { -1 }, List(6) { BottomApproachEstimator.BandUrgency.CLEAR },
                normal, hard, normalLaneStabilizer.update(normal), hardLaneStabilizer.update(hard),
                laneDetection.xPositions, laneDetection.confidence,
                stableLaneDetection.xPositions, stableLaneDetection.confidence)
        }
        val foreground = backgroundModel.update(current)
        val blobs = blobDetector.detectMask(foreground.foregroundMask)
        val candidates = candidateFilter.filter(blobs)
        val shapeCounts = candidates.candidates.map(MotionShapeClassifier::classify)
            .groupingBy { it }.eachCount()
        val tracked = blobTracker.update(candidates.candidates)
        val rolePatterns = tracked.tracks.map { MotionRoleClassifier.classify(it) }
        val horizontalMotionCount = rolePatterns.count { it == MotionRoleClassifier.Pattern.HORIZONTAL }
        val verticalDownCandidateCount = rolePatterns.count { it == MotionRoleClassifier.Pattern.VERTICAL_DOWN }
        val approach = bottomApproachEstimator.estimate(tracked.tracks)
        val crossing = crossingEstimator.estimate(tracked.tracks, smoothedSampleIntervalSeconds)
        // Feed live track predictions into the decision gate. Lane assignment and the
        // chicken lane are intentionally uncalibrated, so the gate must remain DATA_BELUM_CUKUP
        // until those values are measured for the active game mode/device.
        val predictionsByTrack = crossing.predictions.associateBy { it.trackId }
        val decisionApproaches = tracked.tracks.mapNotNull { track ->
            val prediction = predictionsByTrack[track.id] ?: return@mapNotNull null
            CrossingDecisionEngine.VehicleApproach(
                trackId = track.id,
                laneIndex = null,
                secondsToCrossing = (prediction.estimatedSecondsMin + prediction.estimatedSecondsMax) / 2.0,
                confidence = (track.hits / 5.0).coerceIn(0.0, 1.0),
                downwardConfirmed = track.direction == MotionBlobTracker.Direction.DOWN && track.directionChanges == 0,
                observationFresh = track.missedFrames == 0
            )
        }
        val recommendation = crossingDecisionEngine.evaluate(
            CrossingDecisionEngine.Input(
                chickenLaneIndex = null,
                laneCalibrationConfirmed = false,
                laneCoverageComplete = false,
                frameFresh = timestampNs > 0L,
                approaches = decisionApproaches
            )
        )

        val tileCols = 8
        val tileRows = 6
        var changed = 0
        var activeTiles = 0
        var totalCompared = 0
        for (ty in 0 until tileRows) {
            for (tx in 0 until tileCols) {
                var tileChanged = 0
                var tileCompared = 0
                val x0 = tx * sampleWidth / tileCols
                val x1 = (tx + 1) * sampleWidth / tileCols
                val y0 = ty * sampleHeight / tileRows
                val y1 = (ty + 1) * sampleHeight / tileRows
                for (y in y0 until y1) {
                    for (x in x0 until x1) {
                        val index = y * sampleWidth + x
                        if (abs(current[index] - old[index]) >= 22) tileChanged++
                        tileCompared++
                    }
                }
                changed += tileChanged
                totalCompared += tileCompared
                if (tileCompared > 0 && tileChanged.toFloat() / tileCompared >= 0.12f) {
                    activeTiles++
                }
            }
        }
        val percent = if (totalCompared == 0) 0 else changed * 100 / totalCompared
        val normalSummary = normalLaneEstimator.summarize(approach.approaches)
        val hardSummary = hardLaneEstimator.summarize(approach.approaches)
        return Result(percent, activeTiles, tileCols * tileRows, motion.movingBlocks, motion.movingDownBlocks, motion.movingUpBlocks, motion.zoneCounts, blobs.size, blobs.firstOrNull()?.area ?: 0, foreground.foregroundPixels, candidates.candidates.size, candidates.rejectedCount, tracked.tracks.size, tracked.downward, tracked.upward, horizontalMotionCount, verticalDownCandidateCount, approach.nearestFrames, crossing.nearestSamples, crossing.nearestSecondsRange, approach.nearBottomCount, approach.bandCounts, approach.bandNearestFrames, approach.bandUrgency,
            normalSummary, hardSummary, normalLaneStabilizer.update(normalSummary), hardLaneStabilizer.update(hardSummary),
            laneDetection.xPositions, laneDetection.confidence,
            stableLaneDetection.xPositions, stableLaneDetection.confidence,
            shapeCounts[MotionShapeClassifier.Shape.WIDE] ?: 0,
            shapeCounts[MotionShapeClassifier.Shape.TALL] ?: 0,
            shapeCounts[MotionShapeClassifier.Shape.COMPACT] ?: 0,
            shapeCounts[MotionShapeClassifier.Shape.AMBIGUOUS] ?: 0,
            recommendation)
    }

    /** Scan full-resolution vertical contrast because 64px downsampling can erase dashed lane lines. */
    private fun detectLaneBoundaries(image: Image, region: GamePlayfieldRegion): LaneBoundaryDetector.Detection {
        val width = image.width
        val height = image.height
        if (width < 20 || height < 20) return LaneBoundaryDetector.Detection(emptyList(), 0.0)
        val plane = image.planes[0]
        val bytes = plane.buffer.duplicate()
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        val xStart = (region.leftFraction * width).toInt().coerceIn(0, width - 1)
        val xEnd = (region.rightFraction * width).toInt().coerceIn(xStart + 1, width)
        val yStart = (region.topFraction * height + (region.bottomFraction - region.topFraction) * height * 0.10).toInt().coerceIn(0, height - 1)
        val yEnd = (region.bottomFraction * height - (region.bottomFraction - region.topFraction) * height * 0.10).toInt().coerceIn(yStart + 1, height)
        val rowCount = 240
        val scores = DoubleArray(width)
        fun luminance(x: Int, y: Int): Double {
            val offset = y * rowStride + x * pixelStride
            if (offset + 2 >= bytes.limit()) return 0.0
            val r = bytes.get(offset).toInt() and 0xff
            val g = bytes.get(offset + 1).toInt() and 0xff
            val b = bytes.get(offset + 2).toInt() and 0xff
            return (r * 30 + g * 59 + b * 11) / 100.0
        }
        for (x in (xStart + 2).coerceAtMost(width - 3) until (xEnd - 2).coerceAtLeast(xStart + 2)) {
            var contrast = 0.0
            for (sample in 0 until rowCount) {
                val y = yStart + ((sample + 0.5) * (yEnd - yStart) / rowCount).toInt()
                val center = luminance(x, y)
                val neighbor = (luminance(x - 2, y) + luminance(x + 2, y)) / 2.0
                contrast += (center - neighbor).coerceAtLeast(0.0)
            }
            scores[x] = contrast * (270.0 / rowCount)
        }
        return laneBoundaryDetector.detect(scores, width)
    }

    fun reset() {
        previous = null
        previousImageTimestampNs = null
        smoothedSampleIntervalSeconds = 0.2
        motionEstimator.reset()
        backgroundModel.reset()
        blobTracker.reset()
        normalLaneStabilizer.reset()
        hardLaneStabilizer.reset()
        laneBoundaryStabilizer.reset()
    }
}
