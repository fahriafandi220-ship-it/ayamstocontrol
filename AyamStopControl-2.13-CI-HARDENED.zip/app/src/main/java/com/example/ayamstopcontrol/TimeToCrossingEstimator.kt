package com.example.ayamstopcontrol

import kotlin.math.ceil
import kotlin.math.floor

/**
 * Estimates samples and a deliberately broad time range to a provisional crossing row.
 * Capture is throttled to roughly 5 samples/second, but frames may be dropped; seconds
 * are therefore indicative only, never a safety/collision decision. A prediction
 * requires at least three observations with no direction reversal to reduce transient
 * blob/noise triggers; this is still not semantic vehicle recognition.
 */
internal class TimeToCrossingEstimator(
    private val crossingY: Int = 28,
    private val frameHeight: Int = 36,
    private val maxSamplesAhead: Int = 30,
    private val minimumDownSpeed: Double = 0.5,
    private val nominalSampleIntervalSeconds: Double = 0.2,
    private val uncertaintyFraction: Double = 0.35
) {
    data class Prediction(
        val trackId: Int,
        val x: Int,
        val samplesToCrossing: Int,
        val estimatedSecondsMin: Double,
        val estimatedSecondsMax: Double
    )
    data class Summary(val predictions: List<Prediction>, val nearestSamples: Int?, val nearestSecondsRange: ClosedFloatingPointRange<Double>?)

    fun estimate(
        tracks: List<MotionBlobTracker.Track>,
        sampleIntervalSeconds: Double = nominalSampleIntervalSeconds
    ): Summary {
        require(sampleIntervalSeconds.isFinite() && sampleIntervalSeconds > 0.0)
        val predictions = tracks.asSequence()
            .filter {
                it.direction == MotionBlobTracker.Direction.DOWN &&
                    it.hits >= 3 && it.missedFrames == 0 && it.directionChanges == 0 && it.deltaY >= minimumDownSpeed &&
                    it.y < crossingY && crossingY in 0 until frameHeight
            }
            .mapNotNull { track ->
                val samples = ceil((crossingY - track.y).toDouble() / track.deltaY).toInt()
                if (samples !in 1..maxSamplesAhead) null
                else {
                    val nominal = samples * sampleIntervalSeconds
                    val low = (nominal * (1.0 - uncertaintyFraction)).coerceAtLeast(0.0)
                    val high = nominal * (1.0 + uncertaintyFraction)
                    Prediction(track.id, track.x, samples, low, high)
                }
            }
            .sortedBy { it.samplesToCrossing }
            .toList()
        val nearest = predictions.firstOrNull()
        val range = nearest?.let { floor(it.estimatedSecondsMin * 10) / 10.0..(ceil(it.estimatedSecondsMax * 10) / 10.0) }
        return Summary(predictions, nearest?.samplesToCrossing, range)
    }
}
