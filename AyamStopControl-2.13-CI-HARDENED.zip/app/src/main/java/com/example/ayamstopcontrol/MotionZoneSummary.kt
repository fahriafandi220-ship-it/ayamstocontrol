package com.example.ayamstopcontrol

/** Summarizes where image motion vectors occur. Zones are screen regions, never vehicle/lane labels. */
internal object MotionZoneSummary {
    data class Summary(val activeZones: List<String>, val strongestZone: String?, val totalVectors: Int)

    private val names = arrayOf(
        "atas-kiri", "atas-tengah", "atas-kanan",
        "tengah-kiri", "tengah", "tengah-kanan",
        "bawah-kiri", "bawah-tengah", "bawah-kanan"
    )

    fun summarize(counts: IntArray, minimumVectors: Int = 2): Summary {
        if (counts.size != 9) return Summary(emptyList(), null, 0)
        val safeThreshold = minimumVectors.coerceAtLeast(1)
        val active = counts.indices.filter { counts[it] >= safeThreshold }
        val strongest = counts.indices.maxByOrNull { counts[it] }
            ?.takeIf { counts[it] >= safeThreshold }
        return Summary(active.map { names[it] }, strongest?.let { names[it] }, counts.sum())
    }
}
