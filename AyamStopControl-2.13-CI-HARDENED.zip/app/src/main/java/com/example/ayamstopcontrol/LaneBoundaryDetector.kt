package com.example.ayamstopcontrol

import kotlin.math.abs

/**
 * Finds repeated vertical lane-divider candidates from a full-resolution
 * vertical-contrast profile. It reports divider coordinates only; it does not
 * decide the lane count or claim that a divider is valid without confidence.
 */
internal class LaneBoundaryDetector(
    private val minScore: Double = 900.0,
    private val minSpacingAt720: Double = 20.0,
    private val maxSpacingAt720: Double = 120.0,
    private val maxSpacingErrorAt720: Double = 10.0,
    private val minBoundaries: Int = 5
) {
    init {
        require(minScore.isFinite() && minScore > 0.0) { "minScore must be finite and positive" }
        require(minSpacingAt720.isFinite() && minSpacingAt720 > 0.0) {
            "minSpacingAt720 must be finite and positive"
        }
        require(maxSpacingAt720.isFinite() && maxSpacingAt720 > minSpacingAt720) {
            "maxSpacingAt720 must be finite and greater than minSpacingAt720"
        }
        require(maxSpacingErrorAt720.isFinite() && maxSpacingErrorAt720 > 0.0) {
            "maxSpacingErrorAt720 must be finite and positive"
        }
        require(minBoundaries >= 3) { "minBoundaries must be at least 3" }
    }

    data class Detection(val xPositions: List<Int>, val confidence: Double) {
        val detected: Boolean get() = xPositions.size >= 2 && confidence >= 0.35
    }

    fun detect(columnScores: DoubleArray, sourceWidth: Int): Detection {
        if (sourceWidth < 20 || columnScores.size != sourceWidth) return Detection(emptyList(), 0.0)
        val scale = sourceWidth / 720.0
        val threshold = minScore * scale
        val mergeDistance = (4.0 * scale).toInt().coerceAtLeast(2)
        val candidates = ArrayList<Pair<Int, Double>>()

        for (x in 2 until sourceWidth - 2) {
            val score = columnScores[x]
            if (!score.isFinite() || score < threshold) continue
            if (score >= columnScores[x - 1] && score >= columnScores[x + 1]) {
                candidates.add(x to score)
            }
        }
        if (candidates.size < minBoundaries) return Detection(emptyList(), 0.0)

        // Merge nearby local maxima that likely belong to the same painted divider.
        val peaks = ArrayList<Pair<Int, Double>>()
        for (candidate in candidates) {
            val last = peaks.lastOrNull()
            if (last != null && candidate.first - last.first <= mergeDistance) {
                if (candidate.second > last.second) peaks[peaks.lastIndex] = candidate
            } else {
                peaks.add(candidate)
            }
        }
        if (peaks.size < minBoundaries) return Detection(emptyList(), 0.0)

        val minGap = minSpacingAt720 * scale
        val maxGap = maxSpacingAt720 * scale
        val maxError = maxSpacingErrorAt720 * scale
        var best = emptyList<Pair<Int, Double>>()
        var bestScore = 0.0

        // Try each plausible base interval. A monotonic cursor avoids repeatedly
        // allocating suffix lists while looking for the next expected divider.
        for (startIndex in peaks.indices) {
            for (endIndex in startIndex + 1 until peaks.size) {
                val gap = (peaks[endIndex].first - peaks[startIndex].first).toDouble()
                if (gap < minGap || gap > maxGap) continue

                val sequence = ArrayList<Pair<Int, Double>>()
                sequence.add(peaks[startIndex])
                var cursor = startIndex + 1
                var expected = peaks[startIndex].first + gap

                while (cursor < peaks.size) {
                    var nearestIndex = -1
                    var nearestError = Double.POSITIVE_INFINITY
                    var scan = cursor
                    while (scan < peaks.size) {
                        val error = abs(peaks[scan].first - expected)
                        if (error < nearestError) {
                            nearestError = error
                            nearestIndex = scan
                        }
                        if (peaks[scan].first > expected + maxError) break
                        scan++
                    }
                    if (nearestIndex < 0 || nearestError > maxError) break
                    sequence.add(peaks[nearestIndex])
                    cursor = nearestIndex + 1
                    expected += gap
                }

                if (sequence.size < minBoundaries) continue
                val gaps = sequence.zipWithNext { a, b -> (b.first - a.first).toDouble() }
                val meanGap = gaps.average()
                val gapError = gaps.map { abs(it - meanGap) }.average()
                val meanStrength = sequence.map { it.second }.average()
                val score = sequence.size *
                    (1.0 - (gapError / maxError).coerceIn(0.0, 1.0)) *
                    (meanStrength / threshold).coerceAtMost(3.0)
                if (score > bestScore) {
                    bestScore = score
                    best = sequence
                }
            }
        }

        if (best.size < minBoundaries) return Detection(emptyList(), 0.0)
        val gaps = best.zipWithNext { a, b -> (b.first - a.first).toDouble() }
        val meanGap = gaps.average()
        val gapError = gaps.map { abs(it - meanGap) }.average()
        val regularity = (1.0 - gapError / maxError).coerceIn(0.0, 1.0)
        val strength = (best.map { it.second }.average() / threshold / 2.0).coerceIn(0.0, 1.0)
        val countFactor = (best.size / 8.0).coerceIn(0.0, 1.0)
        val confidence = (regularity * 0.65 + strength * 0.25 + countFactor * 0.10)
            .coerceIn(0.0, 1.0)
        return Detection(best.map { it.first }, confidence)
    }
}
