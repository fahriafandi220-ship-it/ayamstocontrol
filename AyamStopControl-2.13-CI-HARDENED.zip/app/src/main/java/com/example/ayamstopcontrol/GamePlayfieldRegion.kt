package com.example.ayamstopcontrol

/**
 * Normalized crop calibrated against the supplied 720x1600 portrait recording:
 * the visible playfield spans approximately y=312..957 px and the full width.
 * Fractions remain configurable because browser chrome, zoom, and game layout
 * can move the arena on other devices. This crop does not calibrate lane count
 * or the chicken crossing row.
 */
internal data class GamePlayfieldRegion(
    val leftFraction: Double = 0.0,
    val topFraction: Double = 0.195,
    val rightFraction: Double = 1.0,
    val bottomFraction: Double = 0.598
) {
    init {
        require(leftFraction in 0.0..1.0 && rightFraction in 0.0..1.0)
        require(topFraction in 0.0..1.0 && bottomFraction in 0.0..1.0)
        require(leftFraction < rightFraction && topFraction < bottomFraction)
    }

    fun sampleX(sampleIndex: Int, sampleCount: Int, sourceWidth: Int): Int =
        sampleCoordinate(sampleIndex, sampleCount, sourceWidth, leftFraction, rightFraction)

    fun sampleY(sampleIndex: Int, sampleCount: Int, sourceHeight: Int): Int =
        sampleCoordinate(sampleIndex, sampleCount, sourceHeight, topFraction, bottomFraction)

    private fun sampleCoordinate(
        sampleIndex: Int,
        sampleCount: Int,
        sourceSize: Int,
        startFraction: Double,
        endFraction: Double
    ): Int {
        require(sampleCount > 0 && sourceSize > 0)
        require(sampleIndex in 0 until sampleCount)
        val start = (startFraction * sourceSize).toInt().coerceIn(0, sourceSize - 1)
        val endExclusive = (endFraction * sourceSize).toInt().coerceIn(start + 1, sourceSize)
        val center = start + ((sampleIndex + 0.5) * (endExclusive - start) / sampleCount).toInt()
        return center.coerceIn(start, endExclusive - 1)
    }
}
