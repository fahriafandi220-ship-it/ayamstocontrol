package com.example.ayamstopcontrol

/**
 * Projects confirmed downward visual tracks toward the bottom edge and groups them
 * into horizontal screen bands. This is NOT vehicle/lane detection or collision prediction.
 */
internal class BottomApproachEstimator(
    private val frameHeight: Int = 36,
    private val frameWidth: Int = 64,
    private val horizontalBands: Int = 6,
    private val nearBottomFraction: Double = 0.78,
    private val maximumFramesAhead: Int = 30
) {
    data class Approach(val trackId: Int, val x: Int, val framesToBottom: Int, val nearBottom: Boolean)
    enum class BandUrgency { CLEAR, WATCH, SOON, IMMEDIATE }
    data class Summary(
        val approaches: List<Approach>,
        val nearestFrames: Int?,
        val nearBottomCount: Int,
        val bandCounts: IntArray,
        /** Minimum projected samples-to-bottom for each horizontal band; -1 means none. */
        val bandNearestFrames: IntArray,
        /** Visual approach urgency only; never a collision/safety verdict. */
        val bandUrgency: List<BandUrgency>
    )

    fun estimate(tracks: List<MotionBlobTracker.Track>): Summary {
        val approaches = tracks.asSequence()
            // Match the stricter crossing predictor: only a fresh, repeatedly observed
            // downward track with no recorded reversal may contribute to urgency.
            .filter {
                it.direction == MotionBlobTracker.Direction.DOWN &&
                    it.hits >= 3 && it.missedFrames == 0 && it.directionChanges == 0 &&
                    it.deltaY > 0.0
            }
            .mapNotNull { track ->
                val remaining = (frameHeight - 1 - track.y).coerceAtLeast(0)
                val frames = kotlin.math.ceil(remaining.toDouble() / track.deltaY).toInt()
                if (frames > maximumFramesAhead) null
                else Approach(track.id, track.x, frames, track.y >= (frameHeight * nearBottomFraction).toInt())
            }
            .sortedBy { it.framesToBottom }
            .toList()
        val bands = IntArray(horizontalBands)
        val nearestByBand = IntArray(horizontalBands) { -1 }
        approaches.forEach { approach ->
            val band = (approach.x * horizontalBands / frameWidth).coerceIn(0, horizontalBands - 1)
            bands[band]++
            if (nearestByBand[band] < 0 || approach.framesToBottom < nearestByBand[band]) {
                nearestByBand[band] = approach.framesToBottom
            }
        }
        val urgency = nearestByBand.map { frames ->
            when {
                frames < 0 -> BandUrgency.CLEAR
                frames <= 2 -> BandUrgency.IMMEDIATE
                frames <= 5 -> BandUrgency.SOON
                else -> BandUrgency.WATCH
            }
        }
        return Summary(approaches, approaches.firstOrNull()?.framesToBottom,
            approaches.count { it.nearBottom }, bands, nearestByBand, urgency)
    }
}
