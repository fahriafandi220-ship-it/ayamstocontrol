package com.example.ayamstopcontrol

import kotlin.math.abs

/** Sparse block matching. Reports image motion only; it never labels an object as a vehicle. */
internal class BlockMotionEstimator(
    private val width: Int = 64,
    private val height: Int = 36,
    private val patchRadius: Int = 2,
    private val searchRadius: Int = 7,
    private val gridStep: Int = 4
) {
    data class Result(
        val movingBlocks: Int,
        val movingDownBlocks: Int,
        val movingUpBlocks: Int,
        val downTop: Int,
        val downMiddle: Int,
        val downBottom: Int,
        val leftMotion: Int,
        val centerMotion: Int,
        val rightMotion: Int,
        /** Row-major 3x3 grid: top-left through bottom-right. */
        val zoneCounts: IntArray
    )

    private var previous: IntArray? = null

    fun update(frame: IntArray): Result {
        if (frame.size != width * height) return emptyResult()
        val old = previous
        previous = frame.copyOf()
        if (old == null) return emptyResult()

        var moving = 0
        var down = 0
        var up = 0
        var downTop = 0
        var downMiddle = 0
        var downBottom = 0
        var leftMotion = 0
        var centerMotion = 0
        var rightMotion = 0
        val zones = IntArray(9)
        val r = patchRadius
        for (y in r + searchRadius until height - r - searchRadius step gridStep) {
            for (x in r + searchRadius until width - r - searchRadius step gridStep) {
                if (textureEnergy(old, x, y, r) < 180) continue
                var bestSad = Int.MAX_VALUE
                var bestDx = 0
                var bestDy = 0
                var secondSad = Int.MAX_VALUE
                for (dy in -searchRadius..searchRadius) {
                    for (dx in -searchRadius..searchRadius) {
                        val sad = patchSad(old, frame, x, y, x + dx, y + dy, r)
                        if (sad < bestSad) {
                            secondSad = bestSad
                            bestSad = sad
                            bestDx = dx
                            bestDy = dy
                        } else if (sad < secondSad) secondSad = sad
                    }
                }
                val pixels = (2 * r + 1) * (2 * r + 1)
                val averageError = bestSad / pixels
                // Require a close and reasonably unique match to avoid random vectors.
                if (averageError <= 12 && secondSad - bestSad >= 18 && (abs(bestDx) + abs(bestDy) >= 1)) {
                    moving++
                    val zoneColumn = (x * 3 / width).coerceIn(0, 2)
                    val zoneRow = (y * 3 / height).coerceIn(0, 2)
                    zones[zoneRow * 3 + zoneColumn]++
                    when {
                        x < width / 3 -> leftMotion++
                        x < width * 2 / 3 -> centerMotion++
                        else -> rightMotion++
                    }
                    if (bestDy >= 1) {
                        down++
                        when {
                            y < height / 3 -> downTop++
                            y < height * 2 / 3 -> downMiddle++
                            else -> downBottom++
                        }
                    } else if (bestDy <= -1) up++
                }
            }
        }
        return Result(moving, down, up, downTop, downMiddle, downBottom, leftMotion, centerMotion, rightMotion, zones)
    }

    private fun textureEnergy(a: IntArray, x: Int, y: Int, r: Int): Int {
        var min = 255
        var max = 0
        for (dy in -r..r) for (dx in -r..r) {
            val v = a[(y + dy) * width + x + dx]
            min = minOf(min, v); max = maxOf(max, v)
        }
        return max - min
    }

    private fun patchSad(a: IntArray, b: IntArray, ax: Int, ay: Int, bx: Int, by: Int, r: Int): Int {
        var sum = 0
        for (dy in -r..r) for (dx in -r..r) {
            sum += abs(a[(ay + dy) * width + ax + dx] - b[(by + dy) * width + bx + dx])
        }
        return sum
    }

    private fun emptyResult() = Result(0, 0, 0, 0, 0, 0, 0, 0, 0, IntArray(9))

    fun reset() { previous = null }
}
