package com.example.ayamstopcontrol

/**
 * Maps confirmed downward visual tracks into configurable horizontal screen slices.
 * The 24/15 slices are provisional coordinate bins, NOT detected game-lane boundaries.
 */
internal class LaneActivityEstimator(
    private val frameWidth: Int = 64,
    private val laneCount: Int
) {
    data class LaneActivity(val laneNumber: Int, val trackCount: Int, val nearestSamplesToBottom: Int?)
    data class Summary(val laneCount: Int, val activeLanes: List<LaneActivity>, val lanes: List<LaneActivity>)

    init { require(laneCount > 0) }

    fun summarize(approaches: List<BottomApproachEstimator.Approach>): Summary {
        val counts = IntArray(laneCount)
        val nearest = arrayOfNulls<Int>(laneCount)
        approaches.forEach { approach ->
            val laneIndex = (approach.x * laneCount / frameWidth).coerceIn(0, laneCount - 1)
            counts[laneIndex]++
            val old = nearest[laneIndex]
            if (old == null || approach.framesToBottom < old) nearest[laneIndex] = approach.framesToBottom
        }
        val lanes = (0 until laneCount).map { index ->
            LaneActivity(index + 1, counts[index], nearest[index])
        }
        return Summary(laneCount, lanes.filter { it.trackCount > 0 }, lanes)
    }
}
