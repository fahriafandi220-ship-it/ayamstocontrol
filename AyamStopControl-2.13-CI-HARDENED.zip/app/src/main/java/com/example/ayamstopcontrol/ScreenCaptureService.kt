package com.example.ayamstopcontrol

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager

/** Captures the user's explicitly approved screen. This stage does not yet classify vehicles. */
class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var worker: HandlerThread? = null
    private var frameHandler: Handler? = null
    private var frameCount = 0L
    private var lastAnalysisAt = 0L
    private val frameAnalyzer = FrameChangeAnalyzer()
    private val directionConsensus = DirectionConsensus()
    private var lastNoticeAt = 0L

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopCapture()
            stopSelf()
            return START_NOT_STICKY
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val permissionData = getPermissionData(intent) ?: run {
            stopSelf()
            return START_NOT_STICKY
        }

        createNotificationChannel()
        val notification = buildNotification("Menyiapkan tangkapan layar…")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, permissionData)
            if (projection == null) throw IllegalStateException("Izin tangkapan layar tidak tersedia")
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    stopCapture()
                    stopSelf()
                }
            }, Handler(mainLooper))
            startFrameCapture()
        } catch (error: Exception) {
            updateNotification("Gagal menangkap layar: ${error.message ?: "izin tidak tersedia"}")
            stopCapture()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun getPermissionData(intent: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_PERMISSION_DATA, Intent::class.java)
        else intent.getParcelableExtra(EXTRA_PERMISSION_DATA)

    private fun startFrameCapture() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels.coerceAtLeast(1)
        val height = metrics.heightPixels.coerceAtLeast(1)
        val density = metrics.densityDpi

        worker = HandlerThread("AyamScreenFrames").also { it.start() }
        frameHandler = Handler(worker!!.looper)
        imageReader = ImageReader.newInstance(width, height, android.graphics.PixelFormat.RGBA_8888, 2)
        imageReader?.setOnImageAvailableListener({ reader ->
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                frameCount++
                val now = android.os.SystemClock.elapsedRealtime()
                // Analyze up to about 5 frames/second so faster motion is less likely to be skipped.
                // This is still a sampling limit, not a guarantee that every game frame is observed.
                if (now - lastAnalysisAt >= 200L) {
                    lastAnalysisAt = now
                    val result = frameAnalyzer.analyze(image)
                    if (frameCount > 1L && now - lastNoticeAt >= 1500L) {
                        lastNoticeAt = now
                        val activity = when {
                            result.changedPercent >= 18 -> "Perubahan layar tinggi"
                            result.changedPercent >= 6 -> "Ada perubahan layar"
                            else -> "Layar relatif tenang"
                        }
                        val stableDirection = directionConsensus.update(result.movingDownBlocks, result.movingUpBlocks)
                        val directionLabel = when (stableDirection) {
                            DirectionConsensus.Direction.DOWN -> "arus visual dominan turun"
                            DirectionConsensus.Direction.UP -> "arus visual dominan naik"
                            DirectionConsensus.Direction.STILL -> "gerak visual minim"
                            DirectionConsensus.Direction.MIXED -> "arah visual belum stabil"
                        }
                        val approachText = result.nearestDownFramesToBottom?.let { "jejak turun terdekat ~${it} sampel ke tepi bawah" }
                        val crossingText = result.nearestDownSamplesToChickenRow?.let { samples ->
                            val seconds = result.nearestCrossingSecondsRange?.let { " (~${it.start}–${it.endInclusive} dtk indikatif)" } ?: ""
                            "perkiraan ke garis ayam ~${samples} sampel$seconds"
                        } ?: "belum ada prediksi ke garis ayam"
                        val bandText = result.downwardBandCounts.indices.joinToString(prefix = " pita-x[", postfix = "]") { index ->
                            val samples = result.downwardBandNearestSamples[index]
                            val urgency = when (result.downwardBandUrgency[index]) {
                                BottomApproachEstimator.BandUrgency.CLEAR -> "kosong"
                                BottomApproachEstimator.BandUrgency.WATCH -> "pantau"
                                BottomApproachEstimator.BandUrgency.SOON -> "mendekat"
                                BottomApproachEstimator.BandUrgency.IMMEDIATE -> "sangat dekat"
                            }
                            if (samples < 0) "${index + 1}:$urgency" else "${index + 1}:$urgency/$samples"
                        }
                        val z = result.motionZoneCounts
                        val grid = "${z[0]}/${z[1]}/${z[2]} | ${z[3]}/${z[4]}/${z[5]} | ${z[6]}/${z[7]}/${z[8]}"
                        val zoneSummary = MotionZoneSummary.summarize(z)
                        val zoneText = if (zoneSummary.activeZones.isEmpty()) "zona aktif belum terdeteksi"
                            else "zona bergerak: ${zoneSummary.activeZones.joinToString()}"
                        val lane24 = result.stableNormal24LaneSummary.activeLanes.joinToString { "${it.laneNumber}:${it.averageTrackCount.toInt()}(${it.presentSamples}/${result.stableNormal24LaneSummary.samplesInWindow})" }.ifEmpty { "belum stabil" }
                        val lane15 = result.stableHard15LaneSummary.activeLanes.joinToString { "${it.laneNumber}:${it.averageTrackCount.toInt()}(${it.presentSamples}/${result.stableHard15LaneSummary.samplesInWindow})" }.ifEmpty { "belum stabil" }
                        val dividerText = if (result.laneBoundaryConfidence >= 0.35) {
                            "garis-pemisah terdeteksi ${result.detectedLaneBoundariesX.size} titik (${result.detectedLaneBoundariesX.joinToString()} px; keyakinan ${(result.laneBoundaryConfidence * 100).toInt()}%)"
                        } else "garis-pemisah belum cukup jelas"
                        val decisionText = when (result.recommendation) {
                            CrossingDecisionEngine.Recommendation.STOP -> "STOP"
                            CrossingDecisionEngine.Recommendation.LANJUT -> "LANJUT"
                            CrossingDecisionEngine.Recommendation.DATA_BELUM_CUKUP -> "DATA BELUM CUKUP (lajur ayam belum dikalibrasi)"
                        }
                        updateNotification("$activity: ${result.changedPercent}% • $directionLabel • turun ${result.movingDownBlocks}, naik ${result.movingUpBlocks} • $zoneText • blob: ${result.motionBlobCount} (terbesar ${result.largestBlobArea} px, foreground ${result.foregroundPixelCount} px, kandidat bentuk ${result.objectCandidateCount}, tersisih ${result.rejectedBlobCount}) • jejak gerak: ${result.trackedMotionCount} (turun ${result.trackedDownCount}, naik ${result.trackedUpCount}) • $approachText • $crossingText • keputusan: $decisionText •$bandText • $dividerText • 24-bin:$lane24 • 15-bin:$lane15 • grid: $grid (bin koordinat visual; belum tervalidasi sebagai lajur game)")
                    }
                }
            } catch (_: Exception) {
                // A dropped/unsupported frame must not crash the capture service.
            } finally {
                image.close()
            }
        }, frameHandler)

        virtualDisplay = projection?.createVirtualDisplay(
            "AyamStopControlCapture", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, frameHandler
        )
        if (virtualDisplay == null) throw IllegalStateException("Virtual display gagal dibuat")
        updateNotification("Tangkapan layar aktif. Analisis perubahan gambar berjalan; belum mengenali kendaraan.")
    }

    @Suppress("DEPRECATION")
    private fun buildNotification(message: String): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID)
        else Notification.Builder(this)
        return builder
            .setContentTitle("Ayam Stop Control")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "Analisis layar", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun updateNotification(message: String) {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .notify(NOTIFICATION_ID, buildNotification(message))
    }

    @Suppress("DEPRECATION")
    private fun stopCapture() {
        try { virtualDisplay?.release() } catch (_: Exception) { }
        virtualDisplay = null
        try { imageReader?.close() } catch (_: Exception) { }
        imageReader = null
        val activeProjection = projection
        projection = null
        try { activeProjection?.stop() } catch (_: Exception) { }
        worker?.quitSafely()
        worker = null
        frameAnalyzer.reset()
        directionConsensus.reset()
        frameCount = 0L
        lastAnalysisAt = 0L
        lastNoticeAt = 0L
        frameHandler = null
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE)
        else stopForeground(true)
    }

    override fun onDestroy() {
        stopCapture()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_STOP = "com.example.ayamstopcontrol.STOP_CAPTURE"
        const val EXTRA_RESULT_CODE = "capture_result_code"
        const val EXTRA_PERMISSION_DATA = "capture_permission_data"
        private const val CHANNEL_ID = "ayam_capture"
        private const val NOTIFICATION_ID = 4102
    }
}
