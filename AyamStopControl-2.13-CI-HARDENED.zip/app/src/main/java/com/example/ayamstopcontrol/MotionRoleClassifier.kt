package com.example.ayamstopcontrol

import kotlin.math.abs

/**
 * Separates trajectory patterns, not semantic object identities.
 * Vertical-dominant tracks are vehicle-like candidates in this game's layout;
 * horizontal-dominant tracks are chicken-like/player-motion candidates.
 */
internal object MotionRoleClassifier {
    enum class Pattern { VERTICAL_DOWN, VERTICAL_UP, HORIZONTAL, UNCERTAIN }

    fun classify(track: MotionBlobTracker.Track, dominanceRatio: Double = 1.25): Pattern {
        val x = abs(track.velocityX)
        val y = abs(track.deltaY)
        if (x < 0.75 && y < 0.75) return Pattern.UNCERTAIN
        if (y >= x * dominanceRatio && y >= 1.0) {
            return if (track.direction == MotionBlobTracker.Direction.DOWN) Pattern.VERTICAL_DOWN
            else if (track.direction == MotionBlobTracker.Direction.UP) Pattern.VERTICAL_UP
            else Pattern.UNCERTAIN
        }
        if (x >= y * dominanceRatio && x >= 1.0) return Pattern.HORIZONTAL
        return Pattern.UNCERTAIN
    }
}
