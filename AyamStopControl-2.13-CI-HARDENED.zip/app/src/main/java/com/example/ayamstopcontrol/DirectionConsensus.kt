package com.example.ayamstopcontrol

import java.util.ArrayDeque

/** Stabilizes coarse image-flow direction over recent samples; not object recognition. */
internal class DirectionConsensus(private val windowSize: Int = 3, private val minimumVotes: Int = 2) {
    enum class Direction { DOWN, UP, MIXED, STILL }
    private val history = ArrayDeque<Direction>()

    fun update(downBlocks: Int, upBlocks: Int): Direction {
        val current = when {
            downBlocks >= 2 && downBlocks >= upBlocks * 2 -> Direction.DOWN
            upBlocks >= 2 && upBlocks >= downBlocks * 2 -> Direction.UP
            downBlocks + upBlocks < 2 -> Direction.STILL
            else -> Direction.MIXED
        }
        history.add(current)
        while (history.size > windowSize) history.removeFirst()
        val downVotes = history.count { it == Direction.DOWN }
        val upVotes = history.count { it == Direction.UP }
        return when {
            downVotes >= minimumVotes -> Direction.DOWN
            upVotes >= minimumVotes -> Direction.UP
            history.all { it == Direction.STILL } -> Direction.STILL
            else -> Direction.MIXED
        }
    }

    fun reset() = history.clear()
}
