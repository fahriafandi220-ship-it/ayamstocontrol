package com.example.ayamstopcontrol

/**
 * Conservative decision gate used by FrameChangeAnalyzer. The current live caller
 * deliberately supplies no chicken-lane calibration or assigned track lanes, so live
 * gameplay remains DATA_BELUM_CUKUP until those measurements are genuinely available.
 * A recommendation is advisory only and is not a safety guarantee.
 */
internal class CrossingDecisionEngine(
    private val stopWithinSeconds: Double = 2.0,
    private val minimumConfidence: Double = 0.70
) {
    enum class Recommendation { STOP, LANJUT, DATA_BELUM_CUKUP }

    data class VehicleApproach(
        val trackId: Int,
        val laneIndex: Int?,
        val secondsToCrossing: Double?,
        val confidence: Double,
        val downwardConfirmed: Boolean,
        val observationFresh: Boolean
    )

    data class Input(
        val chickenLaneIndex: Int?,
        val laneCalibrationConfirmed: Boolean,
        val laneCoverageComplete: Boolean,
        val frameFresh: Boolean,
        val approaches: List<VehicleApproach>
    )

    init {
        require(stopWithinSeconds.isFinite() && stopWithinSeconds > 0.0)
        require(minimumConfidence in 0.0..1.0)
    }

    fun evaluate(input: Input): Recommendation {
        if (!input.laneCalibrationConfirmed ||
            !input.laneCoverageComplete ||
            !input.frameFresh ||
            input.chickenLaneIndex == null ||
            input.chickenLaneIndex < 0
        ) return Recommendation.DATA_BELUM_CUKUP

        val relevant = input.approaches.filter {
            it.observationFresh &&
                it.downwardConfirmed &&
                it.laneIndex != null &&
                it.laneIndex >= 0 &&
                it.secondsToCrossing != null &&
                it.secondsToCrossing.isFinite() &&
                it.secondsToCrossing >= 0.0 &&
                it.confidence.isFinite() &&
                it.confidence in 0.0..1.0
        }

        if (relevant.any {
                it.laneIndex == input.chickenLaneIndex &&
                    it.secondsToCrossing!! <= stopWithinSeconds &&
                    it.confidence >= minimumConfidence
            }) return Recommendation.STOP

        // A clear result is permitted only when all provided approaches are valid,
        // fresh, and confidently assigned. Empty list is allowed only with complete coverage.
        val allUsable = input.approaches.all {
            it.observationFresh &&
                it.downwardConfirmed &&
                it.laneIndex != null && it.laneIndex >= 0 &&
                it.secondsToCrossing != null &&
                it.secondsToCrossing.isFinite() &&
                it.secondsToCrossing >= 0.0 &&
                it.confidence.isFinite() &&
                it.confidence >= minimumConfidence &&
                it.confidence <= 1.0
        }
        if (!allUsable) return Recommendation.DATA_BELUM_CUKUP

        return Recommendation.LANJUT
    }
}
