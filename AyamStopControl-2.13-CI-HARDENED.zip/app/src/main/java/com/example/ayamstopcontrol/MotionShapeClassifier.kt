package com.example.ayamstopcontrol

/**
 * Coarse geometric description of a moving foreground component.
 * These labels describe silhouette proportions only; they do NOT identify a car,
 * motorcycle, chicken, or safe/unsafe traffic.
 */
internal object MotionShapeClassifier {
    enum class Shape { WIDE, TALL, COMPACT, AMBIGUOUS }

    fun classify(blob: MotionBlobDetector.Blob): Shape {
        val width = blob.boxWidth.coerceAtLeast(1)
        val height = blob.boxHeight.coerceAtLeast(1)
        val aspect = width.toDouble() / height
        return when {
            blob.area < 3 || width < 2 || height < 2 -> Shape.AMBIGUOUS
            aspect >= 1.65 -> Shape.WIDE
            aspect <= 0.60 -> Shape.TALL
            aspect in 0.82..1.22 -> Shape.COMPACT
            else -> Shape.AMBIGUOUS
        }
    }
}
