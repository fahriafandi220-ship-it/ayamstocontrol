package com.example.ayamstopcontrol

/**
 * Geometry-only filter for compact foreground components inside the cropped playfield.
 * Output is a visual candidate, never a car/motorcycle classification.
 */
internal class MotionObjectCandidateFilter(
    private val minArea: Int = 3,
    private val maxArea: Int = 150,
    private val minWidth: Int = 2,
    private val maxWidth: Int = 16,
    private val minHeight: Int = 2,
    private val maxHeight: Int = 12,
    private val minFillRatio: Double = 0.08,
    private val minAspectRatio: Double = 0.25,
    private val maxAspectRatio: Double = 4.5
) {
    data class Summary(val candidates: List<MotionBlobDetector.Blob>, val rejectedCount: Int)

    fun filter(blobs: List<MotionBlobDetector.Blob>): Summary {
        val accepted = blobs.filter { blob ->
            val width = blob.boxWidth
            val height = blob.boxHeight
            val aspect = width.toDouble() / height.coerceAtLeast(1)
            val fill = blob.area.toDouble() / (width * height).coerceAtLeast(1)
            blob.area in minArea..maxArea &&
                width in minWidth..maxWidth && height in minHeight..maxHeight &&
                fill >= minFillRatio && aspect in minAspectRatio..maxAspectRatio
        }
        return Summary(accepted, blobs.size - accepted.size)
    }
}
