package com.example.ayamstopcontrol

import android.app.Activity
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val captureRequestCode = 4101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            setBackgroundColor(Color.rgb(247, 248, 250))
        }
        val title = TextView(this).apply {
            text = "AYAM STOP CONTROL"
            textSize = 24f
            setTextColor(Color.rgb(25, 35, 45))
        }
        val info = TextView(this).apply {
            text = "Analisis saat ini: menangkap layar, melacak kandidat gerak, dan menghitung estimasi visual. Rekaman terbaru memperlihatkan pilihan Easy, Medium, Hard, dan Nekat Parah, tetapi belum cukup untuk mengkalibrasi jumlah lajur dan posisi ayam. Mesin keputusan konservatif tersedia sebagai komponen uji terpisah, BELUM terhubung ke analisis layar langsung. Aplikasi belum mengenali mobil vs motor secara semantik dan belum membuktikan jalur aman. Tombol STOP/LANJUT pada panel hanya mengubah label panel; tidak mengendalikan ayam di game. DATA BELUM CUKUP harus dipakai sampai kalibrasi dan cakupan tervalidasi."
            textSize = 16f
            setTextColor(Color.DKGRAY)
            setPadding(0, 20, 0, 20)
        }
        status = TextView(this).apply {
            text = "Status: panel belum aktif"
            textSize = 15f
            setTextColor(Color.rgb(35, 90, 55))
            setPadding(0, 8, 0, 18)
        }
        val launch = Button(this).apply {
            text = "AKTIFKAN PANEL MENGAMBANG"
            setOnClickListener { enableOverlay() }
        }
        val capture = Button(this).apply {
            text = "MULAI TANGKAP LAYAR"
            setOnClickListener { requestScreenCapture() }
        }
        val stopCapture = Button(this).apply {
            text = "HENTIKAN TANGKAP LAYAR"
            setOnClickListener {
                stopService(Intent(this@MainActivity, ScreenCaptureService::class.java))
                status.text = "Tangkapan layar dihentikan."
            }
        }
        val stop = Button(this).apply {
            text = "TUTUP PANEL"
            setOnClickListener {
                stopService(Intent(this@MainActivity, OverlayService::class.java))
                status.text = "Status: panel ditutup"
            }
        }
        root.addView(title)
        root.addView(info)
        root.addView(status)
        root.addView(launch, matchWidth())
        root.addView(capture, matchWidth())
        root.addView(stopCapture, matchWidth())
        root.addView(stop, matchWidth())
        setContentView(root)
    }

    private fun matchWidth(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            status.text = "Izinkan 'Tampil di atas aplikasi lain', lalu kembali dan tekan AKTIFKAN PANEL."
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
            return
        }
        try {
            startService(Intent(this, OverlayService::class.java))
            status.text = "Status: perintah membuka panel dikirim"
        } catch (_: Exception) {
            status.text = "Panel gagal dibuka. Periksa izin overlay lalu coba lagi."
        }
    }

    private fun requestScreenCapture() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        status.text = "Menunggu persetujuan tangkapan layar dari Android…"
        startActivityForResult(manager.createScreenCaptureIntent(), captureRequestCode)
    }

    @Deprecated("Android screen-capture consent callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != captureRequestCode) return
        if (resultCode != RESULT_OK || data == null) {
            status.text = "Izin tangkapan layar dibatalkan. Belum ada layar yang direkam."
            return
        }
        val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
            putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(ScreenCaptureService.EXTRA_PERMISSION_DATA, data)
        }
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent) else startService(serviceIntent)
            status.text = "Izin diterima. Layanan tangkapan layar dimulai; analisis perubahan gambar akan berjalan."
        } catch (_: Exception) {
            status.text = "Layanan tangkapan layar gagal dimulai. Coba buka ulang aplikasi."
        }
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized && Settings.canDrawOverlays(this)) {
            status.text = "Izin overlay aktif. Tekan tombol untuk membuka panel."
        }
    }
}
