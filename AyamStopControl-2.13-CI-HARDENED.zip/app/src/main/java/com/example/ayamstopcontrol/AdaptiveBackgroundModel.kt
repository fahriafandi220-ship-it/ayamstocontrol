package com.example.ayamstopcontrol

import kotlin.math.abs

/**
 * Slow-adapting grayscale background model. Foreground pixels are candidates,
 * not classified vehicles. A robust median luminance offset compensates broad
 * exposure/brightness changes before foreground extraction.
 */
internal class AdaptiveBackgroundModel(
    private val pixelCount: Int = 64 * 36,
    private val threshold: Int = 24,
    private val learningRate: Double = 0.025,
    private val globalShiftThreshold: Int = 18
) {
    private var background: DoubleArray? = null

    data class Result(
        val foregroundMask: BooleanArray,
        val foregroundPixels: Int,
        val initialized: Boolean,
        val globalShiftCompensated: Boolean = false
    )

    init {
        require(pixelCount > 0)
        require(threshold >= 0)
        require(learningRate in 0.0..1.0)
        require(globalShiftThreshold >= 0)
    }

    fun update(frame: IntArray): Result {
        if (frame.size != pixelCount) return Result(BooleanArray(0), 0, false)
        val model = background
        if (model == null) {
            background = DoubleArray(pixelCount) { frame[it].coerceIn(0, 255).toDouble() }
            return Result(BooleanArray(pixelCount), 0, false)
        }

        // Median signed offset is robust to a minority of moving foreground objects.
        val offsets = IntArray(pixelCount) { i -> frame[i].coerceIn(0, 255) - model[i].toInt() }
        offsets.sort()
        val medianOffset = if (pixelCount % 2 == 0)
            (offsets[pixelCount / 2 - 1] + offsets[pixelCount / 2]) / 2
        else offsets[pixelCount / 2]

        if (abs(medianOffset) >= globalShiftThreshold && medianOffset != 0) {
            for (i in model.indices) model[i] = (model[i] + medianOffset).coerceIn(0.0, 255.0)
            return Result(BooleanArray(pixelCount), 0, true, true)
        }

        val mask = BooleanArray(pixelCount)
        var count = 0
        for (i in frame.indices) {
            val value = frame[i].coerceIn(0, 255).toDouble()
            val foreground = abs(value - model[i]) >= threshold
            mask[i] = foreground
            if (foreground) count++
            if (!foreground) model[i] += (value - model[i]) * learningRate
        }
        return Result(mask, count, true, false)
    }

    fun reset() { background = null }
}
