package com.example.ayamstopcontrol

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.ln

/**
 * Multi-frame tracker for visual blobs. The wider default gate tolerates larger per-sample
 * displacement at the faster capture cadence; predicted position and box-shape similarity
 * still help reduce ID swaps. This is NOT
 * vehicle classification or collision prediction.
 */
internal class MotionBlobTracker(
    private val maxCenterDistance: Double = 16.0,
    private val maxMissedFrames: Int = 2,
    private val minimumVerticalShift: Int = 1,
    private val confirmationHits: Int = 2,
    private val shapeWeight: Double = 2.5
) {
    enum class Direction { DOWN, UP, SIDEWAYS, UNKNOWN }
    data class Track(
        val id: Int, val x: Int, val y: Int, val direction: Direction,
        val hits: Int, val deltaY: Double, val velocityX: Double = 0.0,
        val missedFrames: Int = 0, val directionChanges: Int = 0
    )
    data class Summary(val tracks: List<Track>, val downward: Int, val upward: Int, val sideways: Int)

    private data class State(
        val id: Int, var x: Int, var y: Int, var width: Int, var height: Int,
        var missed: Int = 0, var hits: Int = 1,
        var direction: Direction = Direction.UNKNOWN, var directionChanges: Int = 0,
        var velocityX: Double = 0.0, var velocityY: Double = 0.0
    )
    private data class Match(val state: State, val blobIndex: Int, val cost: Double)
    private val states = mutableListOf<State>()
    private var nextId = 1

    fun update(blobs: List<MotionBlobDetector.Blob>): Summary {
        states.forEach { it.missed++ }
        val possible = mutableListOf<Match>()
        states.forEach { state ->
            val px = state.x + state.velocityX * state.missed
            val py = state.y + state.velocityY * state.missed
            blobs.forEachIndexed { index, blob ->
                val distance = hypot(px - blob.centerX, py - blob.centerY)
                val gate = maxCenterDistance + state.missed * 2.5
                if (distance <= gate) {
                    val widthPenalty = abs(ln(blob.boxWidth.toDouble() / state.width.coerceAtLeast(1)))
                    val heightPenalty = abs(ln(blob.boxHeight.toDouble() / state.height.coerceAtLeast(1)))
                    val cost = distance + shapeWeight * (widthPenalty + heightPenalty)
                    possible += Match(state, index, cost)
                }
            }
        }

        val usedStates = mutableSetOf<Int>()
        val usedBlobs = mutableSetOf<Int>()
        possible.sortedBy { it.cost }.forEach { match ->
            val state = match.state
            if (state.id in usedStates || match.blobIndex in usedBlobs) return@forEach
            val blob = blobs[match.blobIndex]
            val dx = blob.centerX - state.x
            val dy = blob.centerY - state.y
            state.velocityX = state.velocityX * 0.55 + dx * 0.45
            state.velocityY = state.velocityY * 0.55 + dy * 0.45
            val observedDirection = when {
                state.velocityY >= minimumVerticalShift -> Direction.DOWN
                state.velocityY <= -minimumVerticalShift -> Direction.UP
                abs(state.velocityX) >= minimumVerticalShift -> Direction.SIDEWAYS
                else -> Direction.UNKNOWN
            }
            if (observedDirection != Direction.UNKNOWN) {
                if (state.direction != Direction.UNKNOWN && observedDirection != state.direction) {
                    state.directionChanges++
                }
                state.direction = observedDirection
            }
            state.x = blob.centerX
            state.y = blob.centerY
            state.width = blob.boxWidth
            state.height = blob.boxHeight
            state.missed = 0
            state.hits++
            usedStates += state.id
            usedBlobs += match.blobIndex
        }

        blobs.forEachIndexed { index, blob ->
            if (index !in usedBlobs) {
                states += State(nextId++, blob.centerX, blob.centerY, blob.boxWidth, blob.boxHeight)
            }
        }
        states.removeAll { it.missed > maxMissedFrames }
        val tracks = states.filter { it.hits >= confirmationHits }.map {
            Track(it.id, it.x, it.y, it.direction, it.hits, it.velocityY, it.velocityX, it.missed, it.directionChanges)
        }
        return Summary(tracks, tracks.count { it.direction == Direction.DOWN },
            tracks.count { it.direction == Direction.UP }, tracks.count { it.direction == Direction.SIDEWAYS })
    }

    fun reset() { states.clear(); nextId = 1 }
}
