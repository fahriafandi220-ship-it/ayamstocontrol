package com.example.ayamstopcontrol

import kotlin.math.abs

/**
 * Temporal confirmation for lane-divider candidates. A divider layout is exposed
 * only after several consecutive frames agree on divider count and position.
 * This prevents one-frame vehicle edges or visual effects from changing the map.
 */
internal class LaneBoundaryStabilizer(
    private val requiredFrames: Int = 3,
    private val maxPositionDriftPx: Int = 12,
    private val historyLimit: Int = 5
) {
    data class StableResult(val xPositions: List<Int>, val confidence: Double) {
        val isStable: Boolean get() = xPositions.size >= 2 && confidence >= 0.35
    }

    private val history = ArrayList<LaneBoundaryDetector.Detection>()

    init {
        require(requiredFrames >= 2)
        require(maxPositionDriftPx >= 1)
        require(historyLimit >= requiredFrames)
    }

    fun update(detection: LaneBoundaryDetector.Detection): StableResult {
        if (!detection.detected || detection.xPositions.size < 2) {
            history.clear()
            return StableResult(emptyList(), 0.0)
        }

        val previous = history.lastOrNull()
        if (previous != null && !matches(previous.xPositions, detection.xPositions)) {
            // Start a fresh confirmation window instead of blending two layouts.
            history.clear()
        }
        history.add(detection)
        while (history.size > historyLimit) history.removeAt(0)

        if (history.size < requiredFrames) return StableResult(emptyList(), 0.0)
        val count = detection.xPositions.size
        if (history.any { it.xPositions.size != count }) {
            history.clear()
            history.add(detection)
            return StableResult(emptyList(), 0.0)
        }

        val stablePositions = (0 until count).map { index ->
            history.map { it.xPositions[index] }.sorted()[history.size / 2]
        }
        val maxDrift = history.maxOf { frame ->
            frame.xPositions.indices.maxOfOrNull { index -> abs(frame.xPositions[index] - stablePositions[index]) } ?: 0
        }
        if (maxDrift > maxPositionDriftPx) {
            history.clear()
            history.add(detection)
            return StableResult(emptyList(), 0.0)
        }
        val consistency = (1.0 - maxDrift.toDouble() / (maxPositionDriftPx + 1)).coerceIn(0.0, 1.0)
        val meanConfidence = history.map { it.confidence }.average()
        return StableResult(stablePositions, (meanConfidence * consistency).coerceIn(0.0, 1.0))
    }

    private fun matches(a: List<Int>, b: List<Int>): Boolean =
        a.size == b.size && a.indices.all { abs(a[it] - b[it]) <= maxPositionDriftPx }

    fun reset() = history.clear()
}
