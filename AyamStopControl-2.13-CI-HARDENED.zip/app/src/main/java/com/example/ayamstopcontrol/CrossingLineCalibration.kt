package com.example.ayamstopcontrol

/**
 * Configurable normalized chicken-crossing row for the downsampled playfield.
 * The default is provisional; calibrate it from the actual chicken path before
 * using crossing-time estimates as gameplay guidance.
 */
internal data class CrossingLineCalibration(val verticalFraction: Double = 0.78) {
    init {
        require(verticalFraction in 0.0..1.0) { "verticalFraction must be between 0 and 1" }
    }

    fun rowFor(frameHeight: Int): Int {
        require(frameHeight > 0) { "frameHeight must be positive" }
        return (frameHeight * verticalFraction).toInt().coerceIn(0, frameHeight - 1)
    }
}
