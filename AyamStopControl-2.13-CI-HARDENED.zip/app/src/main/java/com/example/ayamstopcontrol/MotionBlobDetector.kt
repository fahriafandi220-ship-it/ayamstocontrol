package com.example.ayamstopcontrol

/**
 * Finds connected regions of changed pixels in a downsampled frame pair.
 * These are motion blobs/candidates only: they are NOT classified as cars or motorcycles.
 */
internal class MotionBlobDetector(
    private val width: Int = 64,
    private val height: Int = 36,
    private val pixelThreshold: Int = 22,
    private val minimumArea: Int = 3
) {
    data class Blob(val area: Int, val left: Int, val top: Int, val right: Int, val bottom: Int) {
        val centerX: Int get() = (left + right) / 2
        val centerY: Int get() = (top + bottom) / 2
        val boxWidth: Int get() = right - left + 1
        val boxHeight: Int get() = bottom - top + 1
    }

    fun detect(previous: IntArray, current: IntArray): List<Blob> {
        if (previous.size != width * height || current.size != width * height) return emptyList()
        val mask = BooleanArray(width * height) { absDiff(previous[it], current[it]) >= pixelThreshold }
        return detectMask(mask)
    }

    fun detectMask(mask: BooleanArray): List<Blob> {
        if (mask.size != width * height) return emptyList()
        val visited = BooleanArray(mask.size)
        val blobs = ArrayList<Blob>()
        val queue = IntArray(mask.size)
        for (start in mask.indices) {
            if (!mask[start] || visited[start]) continue
            var head = 0
            var tail = 0
            queue[tail++] = start
            visited[start] = true
            var area = 0
            var minX = width; var minY = height; var maxX = -1; var maxY = -1
            while (head < tail) {
                val index = queue[head++]
                val x = index % width
                val y = index / width
                area++
                minX = minOf(minX, x); maxX = maxOf(maxX, x)
                minY = minOf(minY, y); maxY = maxOf(maxY, y)
                for (dy in -1..1) for (dx in -1..1) {
                    if (dx == 0 && dy == 0) continue
                    val nx = x + dx; val ny = y + dy
                    if (nx !in 0 until width || ny !in 0 until height) continue
                    val ni = ny * width + nx
                    if (mask[ni] && !visited[ni]) {
                        visited[ni] = true
                        queue[tail++] = ni
                    }
                }
            }
            if (area >= minimumArea) blobs.add(Blob(area, minX, minY, maxX, maxY))
        }
        return blobs.sortedByDescending { it.area }
    }

    private fun absDiff(a: Int, b: Int) = kotlin.math.abs(a - b)
}
