package com.example.ayamstopcontrol

/**
 * Temporal filter for provisional screen-coordinate bins.
 * A bin becomes visible after appearing in at least minPresent samples in the window.
 * This reduces flicker; it does not validate game lane boundaries or safety.
 */
internal class LaneActivityStabilizer(
    private val windowSize: Int = 3,
    private val minPresent: Int = 2
) {
    data class StableLane(
        val laneNumber: Int,
        val presentSamples: Int,
        val averageTrackCount: Double,
        val nearestSamplesToBottom: Int?
    )
    data class Summary(val laneCount: Int, val activeLanes: List<StableLane>, val samplesInWindow: Int)

    private val history = ArrayDeque<LaneActivityEstimator.Summary>()
    private var configuredLaneCount: Int? = null

    init {
        require(windowSize > 0)
        require(minPresent in 1..windowSize)
    }

    fun update(summary: LaneActivityEstimator.Summary): Summary {
        if (configuredLaneCount != summary.laneCount) {
            history.clear()
            configuredLaneCount = summary.laneCount
        }
        history.add(summary)
        while (history.size > windowSize) history.removeFirst()

        val stable = (1..summary.laneCount).mapNotNull { laneNumber ->
            val observations = history.map { it.lanes[laneNumber - 1] }
            val present = observations.filter { it.trackCount > 0 }
            if (present.size < minPresent) return@mapNotNull null
            val average = present.sumOf { it.trackCount }.toDouble() / history.size
            val nearest = present.mapNotNull { it.nearestSamplesToBottom }.minOrNull()
            StableLane(laneNumber, present.size, average, nearest)
        }
        return Summary(summary.laneCount, stable, history.size)
    }

    fun reset() {
        history.clear()
        configuredLaneCount = null
    }
}
