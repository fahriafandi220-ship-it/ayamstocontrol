package com.example.ayamstopcontrol

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LaneBoundaryStabilizerTest {
    @Test fun waitsForThreeConsistentFramesAndUsesMedianPositions() {
        val stabilizer = LaneBoundaryStabilizer()
        val a = LaneBoundaryDetector.Detection(listOf(58, 146, 234, 322, 411, 499, 587, 675), 0.98)
        val b = LaneBoundaryDetector.Detection(listOf(65, 153, 241, 329, 417, 505, 594, 682), 0.98)
        val c = LaneBoundaryDetector.Detection(listOf(60, 148, 236, 324, 412, 500, 589, 677), 0.98)

        assertTrue(stabilizer.update(a).xPositions.isEmpty())
        assertTrue(stabilizer.update(b).xPositions.isEmpty())
        val stable = stabilizer.update(c)
        assertEquals(listOf(60, 148, 236, 324, 412, 500, 589, 677), stable.xPositions)
        assertTrue(stable.isStable)
    }

    @Test fun resetsConfirmationWhenLayoutJumpsOrDetectionIsMissing() {
        val stabilizer = LaneBoundaryStabilizer()
        val a = LaneBoundaryDetector.Detection(listOf(58, 146, 234, 322, 411, 499, 587, 675), 0.98)
        val shifted = LaneBoundaryDetector.Detection(listOf(110, 198, 286, 374, 463, 551, 639, 727), 0.98)
        repeat(2) { stabilizer.update(a) }
        assertTrue(stabilizer.update(shifted).xPositions.isEmpty())
        assertTrue(stabilizer.update(LaneBoundaryDetector.Detection(emptyList(), 0.0)).xPositions.isEmpty())
        assertTrue(stabilizer.update(a).xPositions.isEmpty())
    }
}
