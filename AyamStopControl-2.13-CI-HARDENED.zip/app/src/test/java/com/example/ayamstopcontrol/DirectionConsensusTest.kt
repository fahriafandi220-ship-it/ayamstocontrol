package com.example.ayamstopcontrol

import org.junit.Assert.assertEquals
import org.junit.Test

class DirectionConsensusTest {
    @Test fun requiresRepeatedDownwardEvidence() {
        val c = DirectionConsensus()
        assertEquals(DirectionConsensus.Direction.MIXED, c.update(5, 0))
        assertEquals(DirectionConsensus.Direction.DOWN, c.update(6, 0))
    }

    @Test fun rejectsSingleOppositeFrameAsDirectionFlip() {
        val c = DirectionConsensus()
        c.update(5, 0); c.update(5, 0)
        assertEquals(DirectionConsensus.Direction.DOWN, c.update(0, 7))
    }

    @Test fun stationarySamplesBecomeStill() {
        val c = DirectionConsensus()
        c.update(0, 0)
        assertEquals(DirectionConsensus.Direction.STILL, c.update(0, 0))
    }
}
