package com.example.ayamstopcontrol

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class MotionZoneSummaryTest {
    @Test fun reportsOnlyZonesWithEnoughMotionVectors() {
        val s = MotionZoneSummary.summarize(intArrayOf(0, 3, 0, 1, 0, 0, 0, 0, 4))
        assertEquals(listOf("atas-tengah", "bawah-kanan"), s.activeZones)
        assertEquals("bawah-kanan", s.strongestZone)
        assertEquals(8, s.totalVectors)
    }

    @Test fun quietScreenHasNoActiveZone() {
        val s = MotionZoneSummary.summarize(IntArray(9))
        assertEquals(emptyList<String>(), s.activeZones)
        assertNull(s.strongestZone)
        assertEquals(0, s.totalVectors)
    }

    @Test fun invalidGridDoesNotCrashOrInventZones() {
        assertEquals(emptyList<String>(), MotionZoneSummary.summarize(intArrayOf(1, 2)).activeZones)
    }
}
