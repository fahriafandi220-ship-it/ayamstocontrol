package com.example.ayamstopcontrol

import org.junit.Assert.assertEquals
import org.junit.Test

class MotionRoleClassifierTest {
    private fun track(direction: MotionBlobTracker.Direction, dx: Double, dy: Double) =
        MotionBlobTracker.Track(1, 10, 10, direction, 3, dy, dx, 0)

    @Test fun downwardVerticalTrackIsVehicleLikeCandidate() {
        assertEquals(MotionRoleClassifier.Pattern.VERTICAL_DOWN,
            MotionRoleClassifier.classify(track(MotionBlobTracker.Direction.DOWN, 0.4, 3.0)))
    }
    @Test fun horizontalTrackIsPlayerMotionCandidate() {
        assertEquals(MotionRoleClassifier.Pattern.HORIZONTAL,
            MotionRoleClassifier.classify(track(MotionBlobTracker.Direction.SIDEWAYS, 3.0, 0.4)))
    }
    @Test fun upwardTrackIsNotDownwardCandidate() {
        assertEquals(MotionRoleClassifier.Pattern.VERTICAL_UP,
            MotionRoleClassifier.classify(track(MotionBlobTracker.Direction.UP, 0.2, -2.5)))
    }
    @Test fun ambiguousTrackRemainsUncertain() {
        assertEquals(MotionRoleClassifier.Pattern.UNCERTAIN,
            MotionRoleClassifier.classify(track(MotionBlobTracker.Direction.DOWN, 2.0, 2.0)))
    }
}
