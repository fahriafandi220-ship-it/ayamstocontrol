package com.example.ayamstopcontrol

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TimeToCrossingEstimatorTest {
    private fun track(id: Int, y: Int, vy: Double, direction: MotionBlobTracker.Direction = MotionBlobTracker.Direction.DOWN, hits: Int = 3) =
        MotionBlobTracker.Track(id, 20, y, direction, hits, vy, 0.0, 0)

    @Test fun predictsSamplesToConfiguredCrossingRow() {
        val result = TimeToCrossingEstimator(crossingY = 28).estimate(listOf(track(1, 18, 2.0)))
        assertEquals(5, result.nearestSamples)
        assertEquals(1.6, result.nearestSecondsRange!!.start, 0.001)
        assertEquals(3.4, result.nearestSecondsRange!!.endInclusive, 0.001)
    }

    @Test fun usesMeasuredAnalysisIntervalForIndicativeSeconds() {
        val result = TimeToCrossingEstimator(crossingY = 28)
            .estimate(listOf(track(1, 18, 2.0)), sampleIntervalSeconds = 0.8)
        assertEquals(5, result.nearestSamples)
        assertEquals(2.6, result.nearestSecondsRange!!.start, 0.001)
        assertEquals(5.4, result.nearestSecondsRange!!.endInclusive, 0.001)
    }

    @Test fun convertsFastCadenceSamplesUsingMeasuredInterval() {
        val result = TimeToCrossingEstimator(crossingY = 28)
            .estimate(listOf(track(1, 18, 2.0)), sampleIntervalSeconds = 0.2)
        assertEquals(5, result.nearestSamples)
        assertEquals(0.6, result.nearestSecondsRange!!.start, 0.001)
        assertEquals(1.4, result.nearestSecondsRange!!.endInclusive, 0.001)
    }

    @Test fun rejectsInvalidMeasuredIntervals() {
        org.junit.Assert.assertThrows(IllegalArgumentException::class.java) {
            TimeToCrossingEstimator().estimate(emptyList(), sampleIntervalSeconds = 0.0)
        }
    }

    @Test fun ignoresUpwardAndSidewaysTracks() {
        val result = TimeToCrossingEstimator().estimate(listOf(
            track(1, 18, 2.0, MotionBlobTracker.Direction.UP),
            track(2, 18, 2.0, MotionBlobTracker.Direction.SIDEWAYS)
        ))
        assertNull(result.nearestSamples)
    }

    @Test fun ignoresUnconfirmedAndAlreadyPastCrossingTracks() {
        val result = TimeToCrossingEstimator(crossingY = 28).estimate(listOf(
            track(1, 18, 2.0, hits = 1), track(2, 30, 2.0)
        ))
        assertNull(result.nearestSamples)
    }

    @Test fun ignoresTracksMissingOnCurrentSample() {
        val missing = MotionBlobTracker.Track(1, 20, 18, MotionBlobTracker.Direction.DOWN, 3, 2.0, 0.0, 1)
        assertNull(TimeToCrossingEstimator().estimate(listOf(missing)).nearestSamples)
    }

    @Test fun ignoresPredictionsBeyondConfiguredHorizon() {
        val result = TimeToCrossingEstimator(crossingY = 28, maxSamplesAhead = 3)
            .estimate(listOf(track(1, 18, 0.5)))
        assertNull(result.nearestSamples)
    }

    @Test fun rejectsShortOrDirectionUnstableTracks() {
        val estimator = TimeToCrossingEstimator(crossingY = 28, frameHeight = 36)
        val short = track(1, 18, 2.0, hits = 2)
        val reversed = MotionBlobTracker.Track(2, 20, 18, MotionBlobTracker.Direction.DOWN, 4, 2.0, 0.0, 0, 1)
        assertTrue(estimator.estimate(listOf(short, reversed)).predictions.isEmpty())
    }

}
