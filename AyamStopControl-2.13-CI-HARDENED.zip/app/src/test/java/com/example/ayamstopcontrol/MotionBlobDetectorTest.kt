package com.example.ayamstopcontrol

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MotionBlobDetectorTest {
    @Test fun findsOneConnectedChangedRegion() {
        val old = IntArray(64 * 36)
        val now = old.copyOf()
        for (y in 10..12) for (x in 20..23) now[y * 64 + x] = 200
        val blobs = MotionBlobDetector().detect(old, now)
        assertEquals(1, blobs.size)
        assertEquals(12, blobs[0].area)
        assertEquals(20, blobs[0].left)
        assertEquals(23, blobs[0].right)
    }

    @Test fun ignoresTinyNoise() {
        val old = IntArray(64 * 36)
        val now = old.copyOf()
        now[5 * 64 + 5] = 255
        assertTrue(MotionBlobDetector().detect(old, now).isEmpty())
    }

    @Test fun keepsSeparateRegionsSeparate() {
        val old = IntArray(64 * 36)
        val now = old.copyOf()
        for (y in 2..4) for (x in 2..4) now[y * 64 + x] = 180
        for (y in 25..27) for (x in 50..52) now[y * 64 + x] = 180
        assertEquals(2, MotionBlobDetector().detect(old, now).size)
    }
}
