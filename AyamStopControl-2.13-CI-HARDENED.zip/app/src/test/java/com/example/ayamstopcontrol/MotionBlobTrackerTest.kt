package com.example.ayamstopcontrol

import org.junit.Assert.*
import org.junit.Test

class MotionBlobTrackerTest {
    private fun blob(x: Int, y: Int, w: Int = 3, h: Int = 3) =
        MotionBlobDetector.Blob(w * h, x, y, x + w - 1, y + h - 1)

    @Test fun confirmsAndTracksDownward() {
        val tracker = MotionBlobTracker()
        assertTrue(tracker.update(listOf(blob(10, 5))).tracks.isEmpty())
        val result = tracker.update(listOf(blob(10, 9)))
        assertEquals(1, result.downward)
    }

    @Test fun tracksUpward() {
        val tracker = MotionBlobTracker()
        tracker.update(listOf(blob(10, 15)))
        assertEquals(1, tracker.update(listOf(blob(10, 10))).upward)
    }

    @Test fun survivesShortMissAndExpires() {
        val tracker = MotionBlobTracker(maxMissedFrames = 1)
        tracker.update(listOf(blob(10, 5)))
        val id = tracker.update(listOf(blob(10, 9))).tracks.single().id
        tracker.update(emptyList())
        assertEquals(id, tracker.update(listOf(blob(10, 17))).tracks.single().id)
        tracker.update(emptyList()); tracker.update(emptyList())
        assertTrue(tracker.update(emptyList()).tracks.isEmpty())
    }

    @Test fun oneBlobCannotMatchTwoTracks() {
        val tracker = MotionBlobTracker()
        tracker.update(listOf(blob(10, 5), blob(30, 5)))
        assertEquals(2, tracker.update(listOf(blob(11, 9), blob(29, 9))).tracks.size)
        val afterSingle = tracker.update(listOf(blob(20, 13))).tracks
        assertEquals(1, afterSingle.count { it.missedFrames == 0 })
    }

    @Test fun shapeSimilarityHelpsPreserveIdsWhenCandidatesAreClose() {
        val tracker = MotionBlobTracker(maxCenterDistance = 12.0)
        tracker.update(listOf(blob(10, 5, 2, 2), blob(20, 5, 6, 4)))
        val first = tracker.update(listOf(blob(12, 9, 2, 2), blob(18, 9, 6, 4))).tracks.associateBy { it.id }
        assertEquals(2, first.size)
        val next = tracker.update(listOf(blob(16, 13, 2, 2), blob(14, 13, 6, 4))).tracks
        assertEquals(2, next.size)
        assertTrue(next.map { it.id }.containsAll(first.keys))
    }

    @Test fun retainsTrackAcrossLargerPerSampleDisplacement() {
        val tracker = MotionBlobTracker()
        tracker.update(listOf(blob(10, 4)))
        val firstConfirmed = tracker.update(listOf(blob(10, 16))).tracks.single()
        val next = tracker.update(listOf(blob(10, 28))).tracks.single()
        assertEquals(firstConfirmed.id, next.id)
        assertEquals(MotionBlobTracker.Direction.DOWN, next.direction)
        assertEquals(8.37, next.deltaY, 0.001)
    }

    @Test fun resetRestartsIds() {
        val tracker = MotionBlobTracker()
        tracker.update(listOf(blob(5, 5)))
        tracker.reset()
        assertTrue(tracker.update(listOf(blob(5, 5))).tracks.isEmpty())
        assertEquals(1, tracker.update(listOf(blob(5, 9))).tracks.single().id)
    }

    @Test fun recordsDirectionReversalForConfidenceGate() {
        val tracker = MotionBlobTracker(maxCenterDistance = 15.0)
        tracker.update(listOf(blob(10, 5)))
        tracker.update(listOf(blob(10, 9)))
        val reversed = tracker.update(listOf(blob(10, 0))).tracks.single()
        assertEquals(MotionBlobTracker.Direction.UP, reversed.direction)
        assertEquals(1, reversed.directionChanges)
    }

}
