package com.example.ayamstopcontrol

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GamePlayfieldRegionTest {
    @Test fun defaultCropTargetsObservedPortraitGameArena() {
        val region = GamePlayfieldRegion()
        val firstY = region.sampleY(0, 36, 1600)
        val lastY = region.sampleY(35, 36, 1600)
        assertTrue("first row should be inside playfield", firstY in 312..330)
        assertTrue("last row should be inside playfield", lastY in 935..955)
        assertEquals(5, region.sampleX(0, 64, 720))
        assertTrue(region.sampleX(63, 64, 720) >= 700)
    }

    @Test fun samplesStayInsideCustomRegion() {
        val region = GamePlayfieldRegion(leftFraction = 0.1, topFraction = 0.2, rightFraction = 0.9, bottomFraction = 0.8)
        for (i in 0 until 64) assertTrue(region.sampleX(i, 64, 100) in 10..89)
        for (i in 0 until 36) assertTrue(region.sampleY(i, 36, 200) in 40..159)
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsInvertedRegion() { GamePlayfieldRegion(topFraction = 0.8, bottomFraction = 0.2) }
}
