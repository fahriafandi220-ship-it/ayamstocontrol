package com.example.ayamstopcontrol

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AdaptiveBackgroundModelTest {
    @Test fun firstFrameInitializesWithoutForeground() {
        val model = AdaptiveBackgroundModel(12)
        val result = model.update(IntArray(12) { 80 })
        assertFalse(result.initialized)
        assertEquals(0, result.foregroundPixels)
    }

    @Test fun detectsObjectAgainstLearnedBackground() {
        val model = AdaptiveBackgroundModel(20, threshold = 20)
        model.update(IntArray(20) { 40 })
        val frame = IntArray(20) { 40 }
        for (i in 5..9) frame[i] = 180
        val result = model.update(frame)
        assertTrue(result.initialized)
        assertEquals(5, result.foregroundPixels)
    }

    @Test fun stableBackgroundIsNotForeground() {
        val model = AdaptiveBackgroundModel(20)
        val frame = IntArray(20) { 120 }
        model.update(frame)
        assertEquals(0, model.update(frame.copyOf()).foregroundPixels)
    }

    @Test fun compensatesGlobalBrightnessShiftWithoutFloodingForeground() {
        val model = AdaptiveBackgroundModel(12, threshold = 20, globalShiftThreshold = 18)
        model.update(IntArray(12) { 70 })
        val brighter = model.update(IntArray(12) { 115 })
        assertTrue(brighter.globalShiftCompensated)
        assertEquals(0, brighter.foregroundPixels)
        assertEquals(0, model.update(IntArray(12) { 115 }).foregroundPixels)
    }

    @Test fun localObjectStillDetectedWhenMostBackgroundIsStable() {
        val model = AdaptiveBackgroundModel(100, threshold = 20, globalShiftThreshold = 18)
        model.update(IntArray(100) { 50 })
        val frame = IntArray(100) { 50 }
        for (i in 10..19) frame[i] = 180
        val result = model.update(frame)
        assertFalse(result.globalShiftCompensated)
        assertEquals(10, result.foregroundPixels)
    }

    @Test fun resetRequiresFreshInitialization() {
        val model = AdaptiveBackgroundModel(8)
        model.update(IntArray(8) { 20 })
        model.reset()
        assertFalse(model.update(IntArray(8) { 200 }).initialized)
    }
}
