package com.example.ayamstopcontrol

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LaneBoundaryDetectorTest {
    @Test fun detectsRepeatedSeparatorsAndIgnoresIsolatedObjectEdges() {
        val scores = DoubleArray(720)
        listOf(58, 146, 234, 322, 411, 499, 587, 675).forEach { scores[it] = 1800.0 }
        scores[645] = 1500.0 // isolated bright object edge, not part of regular sequence
        val result = LaneBoundaryDetector().detect(scores, 720)
        assertEquals(listOf(58, 146, 234, 322, 411, 499, 587, 675), result.xPositions)
        assertTrue(result.confidence >= 0.35)
        assertTrue(result.detected)
    }

    @Test fun detectsRepeatedSeparatorsWithTwentyPixelSpacing() {
        val scores = DoubleArray(720)
        listOf(100, 120, 140, 160, 180, 200).forEach { scores[it] = 1800.0 }
        val result = LaneBoundaryDetector().detect(scores, 720)
        assertEquals(listOf(100, 120, 140, 160, 180, 200), result.xPositions)
        assertTrue(result.detected)
    }

    @Test fun rejectsUnstructuredMotionEdges() {
        val scores = DoubleArray(720)
        listOf(80, 171, 292, 410, 560).forEach { scores[it] = 1700.0 }
        val result = LaneBoundaryDetector().detect(scores, 720)
        assertTrue(result.xPositions.isEmpty())
        assertEquals(0.0, result.confidence, 0.0)
    }

    @Test fun scalesThresholdsForDifferentCaptureWidths() {
        val scores = DoubleArray(360)
        listOf(29, 73, 117, 161, 205, 249, 293, 337).forEach { scores[it] = 1000.0 }
        val result = LaneBoundaryDetector().detect(scores, 360)
        assertEquals(8, result.xPositions.size)
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsInvalidSpacingConfiguration() {
        LaneBoundaryDetector(minSpacingAt720 = 30.0, maxSpacingAt720 = 20.0)
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsTooFewRequiredBoundaries() {
        LaneBoundaryDetector(minBoundaries = 2)
    }
}
