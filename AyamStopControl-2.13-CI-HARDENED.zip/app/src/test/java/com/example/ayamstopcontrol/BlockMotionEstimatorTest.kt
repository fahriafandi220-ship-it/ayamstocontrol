package com.example.ayamstopcontrol

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BlockMotionEstimatorTest {
    private fun patternedFrame(top: Int): IntArray {
        val frame = IntArray(64 * 36) { 20 }
        for (y in top until top + 12) {
            for (x in 20 until 36) {
                frame[y * 64 + x] = if (((x / 2) + (y / 2)) % 2 == 0) 220 else 80
            }
        }
        return frame
    }

    @Test fun detectsDownwardImageMotion() {
        val estimator = BlockMotionEstimator()
        estimator.update(patternedFrame(8))
        val result = estimator.update(patternedFrame(12))
        assertTrue("expected downward vectors", result.movingDownBlocks > 0)
        assertEquals(0, result.movingUpBlocks)
        assertTrue("downward motion should be localized in a screen band", result.downMiddle + result.downBottom > 0)
        assertTrue("pattern is centered horizontally", result.centerMotion > 0)
        assertEquals(result.movingBlocks, result.zoneCounts.sum())
        assertTrue("center column should contain motion", result.zoneCounts[1] + result.zoneCounts[4] + result.zoneCounts[7] > 0)
    }

    @Test fun detectsUpwardImageMotion() {
        val estimator = BlockMotionEstimator()
        estimator.update(patternedFrame(12))
        val result = estimator.update(patternedFrame(8))
        assertTrue("expected upward vectors", result.movingUpBlocks > 0)
        assertEquals(0, result.movingDownBlocks)
    }

    @Test fun stationaryFrameHasNoMotionVectors() {
        val estimator = BlockMotionEstimator()
        val frame = patternedFrame(8)
        estimator.update(frame)
        val result = estimator.update(frame)
        assertEquals(0, result.movingBlocks)
        assertEquals(0, result.zoneCounts.sum())
    }
}
