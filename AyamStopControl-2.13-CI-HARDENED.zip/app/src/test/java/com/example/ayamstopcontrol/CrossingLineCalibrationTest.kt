package com.example.ayamstopcontrol

import org.junit.Assert.assertEquals
import org.junit.Test

class CrossingLineCalibrationTest {
    @Test fun defaultMatchesPreviousProvisionalSeventyEightPercentRow() {
        assertEquals(28, CrossingLineCalibration().rowFor(36))
    }

    @Test fun modeOrDeviceCanUseAnotherMeasuredCrossingFraction() {
        assertEquals(25, CrossingLineCalibration(0.70).rowFor(36))
        assertEquals(56, CrossingLineCalibration(0.70).rowFor(80))
    }

    @Test fun fractionAtOneIsClampedToLastValidRow() {
        assertEquals(35, CrossingLineCalibration(1.0).rowFor(36))
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsFractionOutsideNormalizedRange() { CrossingLineCalibration(1.1) }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsEmptyFrame() { CrossingLineCalibration().rowFor(0) }
}
