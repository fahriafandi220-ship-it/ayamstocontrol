package com.example.ayamstopcontrol

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LaneActivityStabilizerTest {
    private val estimator = LaneActivityEstimator(frameWidth = 64, laneCount = 24)
    private fun present(x: Int = 5, frames: Int = 7) =
        estimator.summarize(listOf(BottomApproachEstimator.Approach(1, x, frames, false)))
    private fun empty() = estimator.summarize(emptyList())

    @Test fun laneMustAppearInTwoOfThreeSamples() {
        val filter = LaneActivityStabilizer()
        assertTrue(filter.update(present()).activeLanes.isEmpty())
        val stable = filter.update(present()).activeLanes.single()
        assertEquals(1, stable.laneNumber)
        assertEquals(2, stable.presentSamples)
    }

    @Test fun laneDisappearsAfterTwoAbsentSamples() {
        val filter = LaneActivityStabilizer()
        filter.update(present())
        filter.update(present())
        assertEquals(1, filter.update(empty()).activeLanes.size)
        assertTrue(filter.update(empty()).activeLanes.isEmpty())
    }

    @Test fun nearestApproachUsesSmallestObservedSampleCount() {
        val filter = LaneActivityStabilizer()
        filter.update(present(frames = 9))
        val stable = filter.update(present(frames = 4)).activeLanes.single()
        assertEquals(4, stable.nearestSamplesToBottom)
    }

    @Test fun changingBinCountStartsFreshHistory() {
        val filter = LaneActivityStabilizer()
        filter.update(present())
        filter.update(present())
        val other = LaneActivityEstimator(laneCount = 15).summarize(emptyList())
        val stable = filter.update(other)
        assertEquals(15, stable.laneCount)
        assertTrue(stable.activeLanes.isEmpty())
        assertEquals(1, stable.samplesInWindow)
    }
}
