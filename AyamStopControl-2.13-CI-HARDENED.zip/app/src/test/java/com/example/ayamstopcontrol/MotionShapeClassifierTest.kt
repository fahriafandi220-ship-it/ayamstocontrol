package com.example.ayamstopcontrol

import org.junit.Assert.assertEquals
import org.junit.Test

class MotionShapeClassifierTest {
    @Test fun classifiesWideSilhouette() {
        assertEquals(MotionShapeClassifier.Shape.WIDE,
            MotionShapeClassifier.classify(MotionBlobDetector.Blob(12, 0, 0, 5, 2)))
    }

    @Test fun classifiesTallSilhouette() {
        assertEquals(MotionShapeClassifier.Shape.TALL,
            MotionShapeClassifier.classify(MotionBlobDetector.Blob(12, 0, 0, 2, 5)))
    }

    @Test fun classifiesCompactSilhouette() {
        assertEquals(MotionShapeClassifier.Shape.COMPACT,
            MotionShapeClassifier.classify(MotionBlobDetector.Blob(12, 0, 0, 3, 3)))
    }

    @Test fun rejectsTinyOrIntermediateShapeAsAmbiguous() {
        assertEquals(MotionShapeClassifier.Shape.AMBIGUOUS,
            MotionShapeClassifier.classify(MotionBlobDetector.Blob(2, 0, 0, 1, 1)))
        assertEquals(MotionShapeClassifier.Shape.AMBIGUOUS,
            MotionShapeClassifier.classify(MotionBlobDetector.Blob(12, 0, 0, 3, 2)))
    }
}
