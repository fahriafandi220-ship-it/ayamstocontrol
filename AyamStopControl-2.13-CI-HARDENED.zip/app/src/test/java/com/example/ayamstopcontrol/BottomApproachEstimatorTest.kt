package com.example.ayamstopcontrol

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class BottomApproachEstimatorTest {
    @Test fun estimatesFramesForDownwardTrack() {
        val track = MotionBlobTracker.Track(1, 10, 26, MotionBlobTracker.Direction.DOWN, 3, 2.0)
        val result = BottomApproachEstimator().estimate(listOf(track))
        assertEquals(5, result.nearestFrames)
        assertEquals(1, result.approaches.size)
        assertEquals(1, result.bandCounts[0])
        assertEquals(5, result.bandNearestFrames[0])
        assertEquals(BottomApproachEstimator.BandUrgency.SOON, result.bandUrgency[0])
    }

    @Test fun ignoresUpwardAndUnconfirmedTracks() {
        val upward = MotionBlobTracker.Track(1, 10, 26, MotionBlobTracker.Direction.UP, 3, -2.0)
        val newTrack = MotionBlobTracker.Track(2, 10, 26, MotionBlobTracker.Direction.DOWN, 1, 2.0)
        assertNull(BottomApproachEstimator().estimate(listOf(upward, newTrack)).nearestFrames)
    }

    @Test fun ignoresStaleOrDirectionChangingTracks() {
        val missed = MotionBlobTracker.Track(3, 10, 26, MotionBlobTracker.Direction.DOWN, 5, 2.0, missedFrames = 1)
        val reversed = MotionBlobTracker.Track(4, 10, 26, MotionBlobTracker.Direction.DOWN, 5, 2.0, directionChanges = 1)
        val tooFewHits = MotionBlobTracker.Track(5, 10, 26, MotionBlobTracker.Direction.DOWN, 2, 2.0)
        val result = BottomApproachEstimator().estimate(listOf(missed, reversed, tooFewHits))
        assertNull(result.nearestFrames)
        assertEquals(0, result.approaches.size)
    }

    @Test fun ignoresTracksThatWereNotSeenInCurrentFrame() {
        val stale = MotionBlobTracker.Track(6, 10, 26, MotionBlobTracker.Direction.DOWN, 4, 2.0, missedFrames = 2)
        assertNull(BottomApproachEstimator().estimate(listOf(stale)).nearestFrames)
    }

    @Test fun marksTracksNearBottom() {
        val track = MotionBlobTracker.Track(1, 10, 30, MotionBlobTracker.Direction.DOWN, 3, 2.0)
        val result = BottomApproachEstimator().estimate(listOf(track))
        assertEquals(1, result.nearBottomCount)
        assertEquals(1, result.bandCounts[0])
        assertEquals(BottomApproachEstimator.BandUrgency.IMMEDIATE, result.bandUrgency[0])
    }

    @Test fun summarizesDifferentHorizontalBandsIndependently() {
        val left = MotionBlobTracker.Track(1, 4, 26, MotionBlobTracker.Direction.DOWN, 3, 2.0)
        val right = MotionBlobTracker.Track(2, 55, 30, MotionBlobTracker.Direction.DOWN, 3, 2.0)
        val result = BottomApproachEstimator().estimate(listOf(left, right))
        assertEquals(5, result.bandNearestFrames[0])
        assertEquals(3, result.bandNearestFrames[5])
        assertEquals(BottomApproachEstimator.BandUrgency.SOON, result.bandUrgency[0])
        assertEquals(BottomApproachEstimator.BandUrgency.SOON, result.bandUrgency[5])
        assertEquals(BottomApproachEstimator.BandUrgency.CLEAR, result.bandUrgency[2])
    }
}
