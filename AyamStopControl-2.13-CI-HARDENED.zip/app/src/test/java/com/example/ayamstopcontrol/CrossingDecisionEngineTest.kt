package com.example.ayamstopcontrol

import org.junit.Assert.assertEquals
import org.junit.Test

class CrossingDecisionEngineTest {
    private val engine = CrossingDecisionEngine()
    private fun base(
        approaches: List<CrossingDecisionEngine.VehicleApproach> = emptyList()
    ) = CrossingDecisionEngine.Input(
        chickenLaneIndex = 4,
        laneCalibrationConfirmed = true,
        laneCoverageComplete = true,
        frameFresh = true,
        approaches = approaches
    )

    @Test fun missingCalibrationNeverSaysGo() {
        val input = base().copy(laneCalibrationConfirmed = false)
        assertEquals(CrossingDecisionEngine.Recommendation.DATA_BELUM_CUKUP, engine.evaluate(input))
    }

    @Test fun closeConfirmedVehicleInChickenLaneSaysStop() {
        val a = CrossingDecisionEngine.VehicleApproach(1, 4, 1.2, 0.9, true, true)
        assertEquals(CrossingDecisionEngine.Recommendation.STOP, engine.evaluate(base(listOf(a))))
    }

    @Test fun vehicleInOtherLaneDoesNotBlockWhenCoverageIsComplete() {
        val a = CrossingDecisionEngine.VehicleApproach(1, 2, 1.2, 0.9, true, true)
        assertEquals(CrossingDecisionEngine.Recommendation.LANJUT, engine.evaluate(base(listOf(a))))
    }

    @Test fun staleOrUnassignedTrackReturnsInsufficientData() {
        val a = CrossingDecisionEngine.VehicleApproach(1, null, 1.2, 0.9, true, false)
        assertEquals(CrossingDecisionEngine.Recommendation.DATA_BELUM_CUKUP, engine.evaluate(base(listOf(a))))
    }

    @Test fun farVehicleDoesNotBlockWhenCoverageIsComplete() {
        val a = CrossingDecisionEngine.VehicleApproach(1, 4, 3.5, 0.9, true, true)
        assertEquals(CrossingDecisionEngine.Recommendation.LANJUT, engine.evaluate(base(listOf(a))))
    }
    @Test fun exactlyAtStopThresholdSaysStop() {
        val a = CrossingDecisionEngine.VehicleApproach(2, 4, 2.0, 0.9, true, true)
        assertEquals(CrossingDecisionEngine.Recommendation.STOP, engine.evaluate(base(listOf(a))))
    }

    @Test fun lowConfidenceTrackNeverProducesGo() {
        val a = CrossingDecisionEngine.VehicleApproach(3, 2, 4.0, 0.4, true, true)
        assertEquals(CrossingDecisionEngine.Recommendation.DATA_BELUM_CUKUP, engine.evaluate(base(listOf(a))))
    }

    @Test fun staleFrameNeverProducesGo() {
        val input = base().copy(frameFresh = false)
        assertEquals(CrossingDecisionEngine.Recommendation.DATA_BELUM_CUKUP, engine.evaluate(input))
    }

    @Test fun missingChickenLaneNeverProducesGo() {
        val input = base().copy(chickenLaneIndex = null)
        assertEquals(CrossingDecisionEngine.Recommendation.DATA_BELUM_CUKUP, engine.evaluate(input))
    }

    @Test fun invalidNegativeCrossingTimeNeverProducesGo() {
        val a = CrossingDecisionEngine.VehicleApproach(4, 2, -0.1, 0.9, true, true)
        assertEquals(CrossingDecisionEngine.Recommendation.DATA_BELUM_CUKUP, engine.evaluate(base(listOf(a))))
    }

}
