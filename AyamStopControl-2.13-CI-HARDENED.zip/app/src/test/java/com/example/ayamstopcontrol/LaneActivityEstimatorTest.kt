package com.example.ayamstopcontrol

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LaneActivityEstimatorTest {
    @Test fun mapsTracksInto24ProvisionalBins() {
        val estimator = LaneActivityEstimator(frameWidth = 64, laneCount = 24)
        val summary = estimator.summarize(listOf(
            BottomApproachEstimator.Approach(1, 0, 8, false),
            BottomApproachEstimator.Approach(2, 2, 5, false),
            BottomApproachEstimator.Approach(3, 63, 3, true)
        ))
        assertEquals(24, summary.laneCount)
        assertEquals(2, summary.activeLanes.size)
        assertEquals(2, summary.lanes[0].trackCount)
        assertEquals(5, summary.lanes[0].nearestSamplesToBottom)
        assertEquals(1, summary.lanes[23].trackCount)
    }

    @Test fun mapsTracksInto15ProvisionalBins() {
        val estimator = LaneActivityEstimator(frameWidth = 64, laneCount = 15)
        val summary = estimator.summarize(listOf(
            BottomApproachEstimator.Approach(1, 32, 4, false)
        ))
        assertEquals(15, summary.laneCount)
        assertEquals(8, summary.activeLanes.single().laneNumber)
        assertEquals(1, summary.activeLanes.single().trackCount)
    }

    @Test fun emptyFrameHasNoActiveBins() {
        val summary = LaneActivityEstimator(laneCount = 24).summarize(emptyList())
        assertTrue(summary.activeLanes.isEmpty())
        assertEquals(24, summary.lanes.size)
    }
}
