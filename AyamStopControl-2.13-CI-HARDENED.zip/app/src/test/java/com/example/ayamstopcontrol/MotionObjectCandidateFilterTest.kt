package com.example.ayamstopcontrol

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MotionObjectCandidateFilterTest {
    @Test fun acceptsCompactObjectLikeComponent() {
        val blob = MotionBlobDetector.Blob(12, 10, 10, 13, 12)
        val result = MotionObjectCandidateFilter().filter(listOf(blob))
        assertEquals(1, result.candidates.size)
        assertEquals(0, result.rejectedCount)
    }

    @Test fun rejectsLargeUiLikeRegion() {
        val blob = MotionBlobDetector.Blob(180, 2, 2, 30, 20)
        val result = MotionObjectCandidateFilter().filter(listOf(blob))
        assertTrue(result.candidates.isEmpty())
        assertEquals(1, result.rejectedCount)
    }

    @Test fun rejectsVeryThinComponent() {
        val blob = MotionBlobDetector.Blob(12, 10, 10, 20, 10)
        assertTrue(MotionObjectCandidateFilter().filter(listOf(blob)).candidates.isEmpty())
    }

    @Test fun keepsAcceptedAndRejectedCountsSeparate() {
        val good = MotionBlobDetector.Blob(9, 1, 1, 3, 3)
        val bad = MotionBlobDetector.Blob(90, 10, 10, 30, 20)
        val result = MotionObjectCandidateFilter().filter(listOf(good, bad))
        assertEquals(1, result.candidates.size)
        assertEquals(1, result.rejectedCount)
    }
}
