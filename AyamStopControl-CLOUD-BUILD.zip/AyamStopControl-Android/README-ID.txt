AYAM STOP CONTROL — PROYEK SUMBER ANDROID (BUKAN APK)

FUNGSI YANG TERSEDIA
- Aplikasi utama dengan tombol untuk meminta izin overlay Android.
- Service panel mengambang yang didaftarkan pada AndroidManifest.xml.
- Panel dapat digeser dari bagian judul.
- STOP dan LANJUT mengubah indikator status panel secara lokal.
- TUTUP PANEL menghentikan service dan menghapus panel.

BATASAN PENTING
Tombol STOP/LANJUT TIDAK menghentikan karakter lawan/kendaraan dan tidak
mengubah gerakan karakter pemain, memori game, server, hasil permainan, atau
logika internal Ayam Nekat maupun game lain. Panel overlay Android biasa tidak
mempunyai kemampuan tersebut. Proyek ini tidak boleh dianggap sebagai alat
cheat atau pengendali game.

CARA MEMBUAT APK
1. Ekstrak ZIP ini di komputer.
2. Buka folder AyamStopControl-Android menggunakan Android Studio.
3. Gunakan JDK 17 dan tunggu Gradle Sync selesai.
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug biasanya tersedia di app/build/outputs/apk/debug/app-debug.apk.
6. Pindahkan APK ke HP Android dan pasang. Jika diminta, izinkan pemasangan
   aplikasi dari sumber yang digunakan.
7. Buka Ayam Stop Control, izinkan 'Tampil di atas aplikasi lain', lalu tekan
   AKTIFKAN PANEL MENGAMBANG.

KONFIGURASI
- Android Gradle Plugin: 8.7.3
- Kotlin Android plugin: 2.0.21
- compileSdk: 35
- minSdk: 23
- targetSdk: 35

STATUS PENGUJIAN
Sumber dan XML dapat diperiksa secara lokal, tetapi APK belum dibangun atau
dipasang pada perangkat Android dalam sesi ini. Pengujian di game Ayam Nekat
belum dilakukan. Jangan anggap fitur pengendalian game telah berhasil.
