package com.example.ayamstopcontrol

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            setBackgroundColor(Color.rgb(247, 248, 250))
        }
        val title = TextView(this).apply {
            text = "AYAM STOP CONTROL"
            textSize = 24f
            setTextColor(Color.rgb(25, 35, 45))
        }
        val info = TextView(this).apply {
            text = "Panel mengambang untuk pintasan tampilan. STOP dan LANJUT hanya mengubah status panel; aplikasi ini tidak mengendalikan karakter, kendaraan, atau logika internal Ayam Nekat maupun game lain."
            textSize = 16f
            setTextColor(Color.DKGRAY)
            setPadding(0, 20, 0, 20)
        }
        status = TextView(this).apply {
            text = "Status: panel belum aktif"
            textSize = 15f
            setTextColor(Color.rgb(35, 90, 55))
            setPadding(0, 8, 0, 18)
        }
        val launch = Button(this).apply {
            text = "AKTIFKAN PANEL MENGAMBANG"
            setOnClickListener { enableOverlay() }
        }
        val stop = Button(this).apply {
            text = "TUTUP PANEL"
            setOnClickListener {
                stopService(Intent(this@MainActivity, OverlayService::class.java))
                status.text = "Status: panel ditutup"
            }
        }
        root.addView(title)
        root.addView(info)
        root.addView(status)
        root.addView(launch, matchWidth())
        root.addView(stop, matchWidth())
        setContentView(root)
    }

    private fun matchWidth(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            status.text = "Izinkan 'Tampil di atas aplikasi lain', lalu kembali dan tekan AKTIFKAN PANEL."
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
            return
        }
        try {
            startService(Intent(this, OverlayService::class.java))
            status.text = "Status: perintah membuka panel dikirim"
        } catch (_: Exception) {
            status.text = "Panel gagal dibuka. Periksa izin overlay lalu coba lagi."
        }
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized && Settings.canDrawOverlays(this)) {
            status.text = "Izin overlay aktif. Tekan tombol untuk membuka panel."
        }
    }
}
