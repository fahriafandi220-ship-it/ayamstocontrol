package com.example.ayamstopcontrol

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** A local floating panel. Its STOP button changes this panel's state only. */
class OverlayService : Service() {
    private var windowManager: WindowManager? = null
    private var panel: LinearLayout? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 10, 14, 12)
            setBackgroundColor(Color.rgb(32, 32, 51))
        }
        val header = TextView(this).apply {
            text = "AYAM STOP CONTROL  •  GESER DI SINI"
            setTextColor(Color.WHITE)
            textSize = 12f
            setPadding(4, 4, 4, 10)
            setOnTouchListener(DragListener())
        }
        val state = TextView(this).apply {
            text = "STATUS: AKTIF (LOKAL)"
            setTextColor(Color.rgb(170, 235, 180))
            textSize = 13f
            setPadding(4, 4, 4, 8)
        }
        val stop = Button(this).apply {
            text = "STOP"
            setOnClickListener {
                state.text = "STATUS: STOP (PANEL SAJA)"
                state.setTextColor(Color.rgb(255, 190, 150))
            }
        }
        val resume = Button(this).apply {
            text = "LANJUT"
            setOnClickListener {
                state.text = "STATUS: AKTIF (LOKAL)"
                state.setTextColor(Color.rgb(170, 235, 180))
            }
        }
        val close = Button(this).apply {
            text = "TUTUP PANEL"
            setOnClickListener { stopSelf() }
        }
        box.addView(header)
        box.addView(state)
        box.addView(stop)
        box.addView(resume)
        box.addView(close)
        panel = box

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 20
            y = 160
        }
        layoutParams = params
        try {
            windowManager?.addView(box, params)
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private inner class DragListener : View.OnTouchListener {
        private var startX = 0
        private var startY = 0
        private var touchX = 0f
        private var touchY = 0f

        override fun onTouch(view: View, event: MotionEvent): Boolean {
            val params = layoutParams ?: return false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX - (event.rawX - touchX).toInt()
                    params.y = startY + (event.rawY - touchY).toInt()
                    val currentPanel = panel ?: return false
                    try { windowManager?.updateViewLayout(currentPanel, params) } catch (_: Exception) { }
                    return true
                }
            }
            return false
        }
    }

    override fun onDestroy() {
        panel?.let { view ->
            try { windowManager?.removeView(view) } catch (_: Exception) { }
        }
        panel = null
        layoutParams = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
